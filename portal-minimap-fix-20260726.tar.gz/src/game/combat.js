export { createCombatGame } from "./combatOrchestrator.js?v=20260726-portalfix1";

﻿# VoidSector - Note de reprise

Ce projet est un prototype de jeu navigateur spatial inspire de DarkOrbit.
Il est deploye sur Vercel et pousse sur GitHub.

- GitHub : https://github.com/Woulette/voidsector_game
- Vercel production : https://voidsector-game.vercel.app
- Dossier local principal : `C:\Users\Ntmav\Desktop\voidsector_game`

Important : il ne doit rester qu'une seule version du jeu dans ce dossier. Une ancienne copie imbriquee `voidsector_game\voidsector_game` a ete supprimee. Ne pas recreer ou modifier une copie imbriquee.

## Lancement Local

Depuis PowerShell dans `C:\Users\Ntmav\Desktop\voidsector_game` :

```powershell
python -m http.server 8765 --bind 127.0.0.1
```

Puis ouvrir :

```text
http://127.0.0.1:8765/index.html
```

Si le navigateur affiche une ancienne version, faire `Ctrl + F5`.

## Architecture

- `index.html` : structure HTML du dashboard et de l'ecran combat.
- `styles.css` : tout le style visuel.
- `game.js` : point d'entree, importe `src/app.js`.
- `src/app.js` : initialisation, navigation, achats, equipement, handlers UI.
- `src/data/catalog.js` : vaisseaux, equipements, munitions, drones, portails, quetes, etat initial.
- `src/core/store.js` : sauvegarde localStorage, inventaire, loadouts, stats, achats, helpers metier.
- `src/core/keybinds.js` : touches configurables des slots combat.
- `src/core/utils.js` : utilitaires.
- `src/ui/render.js` : rendu du hangar, magasin, portails, competences, leaderboard.
- `src/ui/toast.js` : notifications.
- `src/game/combat.js` : canvas, maps, ennemis, combat, munitions, mini-map, portails.

## Etat Actuel Du Jeu

Le jeu utilise une architecture modulaire, pas un gros `game.js`.

Fonctionnalites importantes deja presentes :

- Hangar avec vaisseaux possedes.
- Onglets de hangar : vaisseau, drone, parametres.
- Inventaire par exemplaire unique : un laser achete = un exemplaire equipable.
- Equipement de lasers, generateurs et extras sur les vaisseaux.
- Drones achetables avec slots d'equipement.
- Magasin avec categories : vaisseaux, armes, munitions, generateurs, drones, extras, modules, premium, possedes.
- Munitions laser et roquettes.
- Les lasers equipes sont passifs en combat : la munition active declenche la salve.
- Une salve consomme une munition par laser equipe.
- Maps ASTRA avec ennemis, spawn, portails, mini-map, radar.
- Loot popup, degats au-dessus des ennemis, cible selectionnee.
- Progression pilote, niveaux, rangs, score, quetes, portails.
- Deploiement Vercel deja configure.

## Points Corriges Recemment

- L'ancienne copie imbriquee du jeu a ete supprimee.
- Le remote GitHub pointe vers `https://github.com/Woulette/voidsector_game.git`.
- Vercel CLI a ete mis a jour et le projet est deploye.
- `.vercel` est ignore par Git.
- Les anciens inventaires avec UID dupliques sont repares au chargement.
- Quand un vaisseau a tous ses slots remplis, equiper un nouvel objet remplace le premier slot compatible.
- Les modifications de loadout sont forcees dans `store.state.shipLoadouts[ship.id]` pour eviter qu'un ancien objet de loadout soit repris au rendu.

## Commandes Utiles

Verifier Git :

```powershell
git status --short --branch
git log --oneline --max-count=5
```

Commit et push :

```powershell
git add .
git commit -m "Message du commit"
git push
```

Deployer sur Vercel :

```powershell
vercel --prod
```

Verifier la syntaxe JS :

```powershell
node --check src/app.js
node --check src/core/store.js
node --check src/ui/render.js
node --check src/game/combat.js
node --check src/data/catalog.js
```

## Consignes Pour Le Prochain Chat

Avant de coder, lire le projet actuel depuis le dossier racine :

```text
C:\Users\Ntmav\Desktop\voidsector_game
```

Ne pas repartir d'une ancienne version monolithique. Le bon projet est celui qui contient `src/`.

Ne pas supprimer les changements existants sans demande explicite.

Quand une modification touche l'equipement ou le combat, tester au minimum :

- Achat d'un laser dans le magasin.
- Equipement du laser dans le hangar.
- Lancement mission.
- Selection d'une munition en slot 1-9.
- Verification qu'il n'y a pas d'erreur console.

## Message Court A Donner Au Prochain Chat

```text
Je travaille sur VoidSector, un jeu navigateur spatial style DarkOrbit.
Le projet est dans C:\Users\Ntmav\Desktop\voidsector_game.
Lis README.md puis inspecte le projet avant de coder.
Le bon projet est la version modulaire avec src/, pas une ancienne version monolithique.
Le jeu est deja sur GitHub et Vercel.
Je veux continuer proprement sans casser le hangar, l'inventaire par exemplaire unique, les munitions et le combat.
```

export function normalizeShipAccessRole(role){
  return String(role || "player").trim().toLowerCase();
}

export function getShipAllowedRoles(ship){
  if(!Array.isArray(ship?.allowedRoles)) return [];
  return [...new Set(ship.allowedRoles.map(normalizeShipAccessRole).filter(Boolean))];
}

export function canAccountRoleAccessShip(ship, role){
  const allowedRoles = getShipAllowedRoles(ship);
  return allowedRoles.length === 0 || allowedRoles.includes(normalizeShipAccessRole(role));
}

export function getShipRoleLockReason(ship, role){
  if(canAccountRoleAccessShip(ship, role)) return "";
  return `${ship?.name || "Ce vaisseau"} est reserve aux comptes OWN et admin.`;
}

export const ships = [
  {
    id:"orion",
    name:"Orion",
    className:"Chasseur polyvalent",
    img:"assets/ships/Orion.png",
    rarity:"Commun",
    rarityTier:"common",
    priceType:"credits",
    price:0,
    desc:"Un chasseur léger et équilibré, parfait pour apprendre à piloter et découvrir les premiers secteurs.",
    stats:{vie:5000, vitesse:300, cargo:250, maxLasers:1, maxGenerators:1, maxExtras:1},
    special:null
  },
  {
    id:"velox",
    name:"Velox",
    className:"Intercepteur rapide",
    img:"assets/ships/Velox.png",
    combatImg:"assets/ships/combat/Velox.png",
    rarity:"Commun",
    rarityTier:"common",
    priceType:"credits",
    price:35000,
    desc:"Rapide et maniable, le Velox est taillé pour les pilotes qui préfèrent esquiver plutôt qu'encaisser.",
    stats:{vie:15000, vitesse:330, cargo:500, maxLasers:3, maxGenerators:3, maxExtras:2},
    special:null
  },
  {
    id:"valkyrie",
    name:"Valkyrie",
    className:"Croiseur d'assaut",
    img:"assets/ships/Valkyrie.png?v=20260726-kharon1",
    rarity:"Rare",
    rarityTier:"rare",
    priceType:"credits",
    price:500000,
    desc:"Un croiseur d'assaut équilibré qui offre assez de puissance et de résistance pour affronter des secteurs plus hostiles.",
    stats:{vie:50000, vitesse:300, cargo:1000, maxLasers:6, maxGenerators:7, maxExtras:3},
    special:null
  },
  {
    id:"razorion",
    name:"Razorion",
    className:"Chasseur d'elite",
    img:"assets/ships/Razorion.png",
    rarity:"Rare",
    rarityTier:"rare",
    priceType:"credits",
    price:2500000,
    desc:"Un chasseur d'élite doté d'une puissance de feu impressionnante, conçu pour dominer les combats rapides.",
    stats:{vie:35000, vitesse:330, cargo:700, maxLasers:8, maxGenerators:5, maxExtras:3},
    special:null
  },
  {
    id:"helion_titan",
    name:"Helion Titan",
    className:"Cuirasse lourde",
    img:"assets/ships/Helion Titan.png",
    rarity:"Très rare",
    rarityTier:"veryRare",
    priceType:"credits",
    price:10000000,
    desc:"Une cuirasse massive faite pour tenir la ligne, absorber les tirs ennemis et soutenir les affrontements les plus longs.",
    stats:{vie:80000, vitesse:270, cargo:1500, maxLasers:6, maxGenerators:10, maxExtras:5},
    special:null
  },
  {
    id:"astralis",
    name:"Astralis",
    className:"Intercepteur astral",
    img:"assets/ships/Astralis.png",
    rarity:"Très rare",
    rarityTier:"veryRare",
    priceType:"credits",
    price:25000000,
    desc:"Un intercepteur astral avancé qui réunit vitesse, capacité d'emport et armement dans une coque particulièrement polyvalente.",
    stats:{vie:70000, vitesse:340, cargo:1500, maxLasers:10, maxGenerators:7, maxExtras:5},
    special:null
  },
  {
    id:"vesperion",
    name:"Vesperion",
    className:"Prédateur vampirique",
    img:"assets/ships/Vesperion.png",
    combatImg:"assets/ships/combat/Vesperion.png",
    rarity:"Élite",
    rarityTier:"elite",
    renderWidth:148,
    renderHeight:148,
    priceType:"premium",
    price:150000,
    desc:"Un prédateur lourd conçu autour d'un noyau de récupération énergétique. Son Tir absorbant reconvertit temporairement la moitié des dégâts réellement infligés en points de coque.",
    stats:{
      vie:230000,
      vitesse:310,
      cargo:2500,
      maxLasers:14,
      maxGenerators:14,
      maxExtras:8,
      maxRocketLaunchers:1,
      maxMissileLaunchers:1
    },
    requiresCompletedPortal:"red",
    skillShip:true,
    abilityId:"absorbing_fire",
    special:"Tir absorbant · 50 % vol de vie · 20 s · recharge 180 s"
  },
  {
    id:"nyxaris",
    name:"Nyxaris",
    className:"Diffuseur toxique",
    img:"assets/ships/Nyxaris.png",
    combatImg:"assets/ships/combat/Nyxaris.png",
    rarity:"Élite",
    rarityTier:"elite",
    renderWidth:128,
    renderHeight:144,
    priceType:"premium",
    price:150000,
    desc:"Un vaisseau leger a noyau toxique qui projette une Bombe poison en vagues concentriques. Les monstres touches subissent un poison direct sur la coque, rafraichi a chaque nouvelle vague.",
    stats:{
      vie:210000,
      vitesse:320,
      cargo:2000,
      maxLasers:14,
      maxGenerators:14,
      maxExtras:8,
      maxRocketLaunchers:1,
      maxMissileLaunchers:1
    },
    requiresCompletedPortal:"red",
    skillShip:true,
    abilityId:"poison_bomb",
    special:"Bombe poison - 5 vagues / 10 s - 10 000 HP/s pendant 10 s - recharge 180 s"
  },
  {
    id:"asterion",
    name:"Asterion",
    className:"Intercepteur spectral",
    img:"assets/ships/Asterion.png",
    combatImg:"assets/ships/combat/Asterion.png",
    rarity:"Élite",
    rarityTier:"elite",
    renderWidth:122,
    renderHeight:132,
    priceType:"premium",
    price:150000,
    desc:"Un intercepteur gris a cadence spectrale. Sa Salve spectrale surcharge les lasers pendant un court laps de temps : une charge se prepare en 3 secondes, puis le prochain tir laser declenche un second impact violet amplifie.",
    stats:{
      vie:180000,
      vitesse:330,
      cargo:2000,
      maxLasers:10,
      maxGenerators:14,
      maxExtras:8,
      maxRocketLaunchers:1,
      maxMissileLaunchers:1
    },
    requiresCompletedPortal:"red",
    skillShip:true,
    abilityId:"spectral_double_shot",
    special:"Salve spectrale - charge 3 s puis prochain tir laser double - 30 s - recharge 180 s"
  },
  {
    id:"imperial",
    name:"Impérial",
    className:"Cuirassé de commandement",
    img:"assets/ships/Imperial.png",
    combatImg:"assets/ships/Imperial.png",
    rarity:"Mythique",
    rarityTier:"mythic",
    renderWidth:170,
    renderHeight:170,
    priceType:"credits",
    price:0,
    allowedRoles:["owner", "admin"],
    desc:"Un cuirassé de commandement réservé aux comptes OWN et admin. Sa coque titanesque et ses systèmes impériaux multiplient par dix les dégâts de toutes les armes.",
    stats:{
      vie:1_000_000,
      vitesse:400,
      cargo:5_000,
      maxLasers:15,
      maxGenerators:15,
      maxExtras:10,
      maxRocketLaunchers:1,
      maxMissileLaunchers:1,
      damageMultiplier:10
    },
    special:"Puissance impériale · dégâts de toutes les armes ×10"
  }
];

import { equipment, portals } from "../../data/catalog.js?v=20260726-prismatic1";
import { fmt } from "../../core/utils.js";
import { lootNameWithRarityHtml } from "../../ui/lootRarityDisplay.js";
import { SAFE_ZONE_DELAY } from "../combatData.js?v=20261022-helion-hub1";
import { createProjectile } from "./projectiles.js?v=20260726-kharon1";
import { buildPortalEnvironment, createPortalMap } from "./portalState.js?v=20261022-helion-hub1";
import { createRemoteWeaponEventProcessor } from "./combatRemoteWeaponEvents.js?v=20260726-combat-authority1";
import { createQuestServerEventProcessor } from "./combatQuestServerEvents.js?v=20260726-kharon1";
import { countCombatProfiler, isCombatProfilerFlagEnabled, setCombatProfilerMetric, timeCombatProfiler } from "./combatFrameProfiler.js?v=20260726-kharon1";

const RICKY_ALLY_ID = "ricky_companion";
const RICKY_ROCKET_PROJECTILE = "assets/equipment/rocket_r2_projectile.png";
const MAX_SERVER_ENEMY_PROJECTILES = 24;
const MAX_SERVER_ENEMY_PROJECTILES_PER_FRAME = 8;
const MAX_SERVER_ENEMY_ATTACK_PARTICLES_PER_FRAME = 8;
const COMBAT_DAMAGE_TEXT_MERGE_MS = 120;
const COMBAT_VISUAL_MAX_AGE_MS = 2000;

export function applyAuthoritativeCombatAmmo({event, playerId, ammoInventory} = {}){
  const consumed = Math.max(0, Math.round(Number(event?.consumed || 0)));
  const ammoId = String(event?.ammoId || "");
  if(consumed <= 0
    || !ammoId
    || String(event?.attackerId || "") !== String(playerId || "")
    || !ammoInventory){
    return false;
  }
  const authoritativeRemaining = Number(event?.ammoRemaining);
  if(Number.isFinite(authoritativeRemaining)){
    ammoInventory[ammoId] = Math.max(0, authoritativeRemaining);
  }else{
    const current = Math.max(0, Number(ammoInventory[ammoId] || 0));
    ammoInventory[ammoId] = Math.max(0, current - consumed);
  }
  return true;
}

export function applyAuthoritativeRewardProgression({event, player} = {}){
  const progression = event?.progression;
  if(!player || !progression || typeof progression !== "object") return false;
  for(const [field, value] of Object.entries(progression)){
    if(value === undefined) continue;
    player[field] = value;
  }
  return true;
}

export function getNpcDamageDisplayAmount(event = {}){
  const totalDamage = Number(event.amount);
  if(Number.isFinite(totalDamage)) return Math.max(0, Math.round(totalDamage));
  return Math.max(0, Math.round(Number(event.hpLost || 0)));
}

export function normalizeSpectralDoubleShotChargeStatus(status = {}, {
  ownerId = "",
  playerId = "",
  activeShipId = "",
  now = Date.now(),
  localReceivedAt = now,
  serverAt = status?.at
} = {}){
  if(String(status?.abilityId || "") !== "spectral_double_shot") return null;
  if(ownerId && String(ownerId) !== String(playerId || "")) return null;
  const shipId = String(status.shipId || activeShipId || "");
  if(activeShipId && shipId && shipId !== String(activeShipId)) return null;

  const localNow = Number.isFinite(Number(now)) ? Number(now) : Date.now();
  const localAnchor = Number.isFinite(Number(localReceivedAt)) ? Number(localReceivedAt) : localNow;
  const serverAnchor = Number(serverAt);
  const clockOffset = Number.isFinite(serverAnchor) && serverAnchor > 0 ? localAnchor - serverAnchor : 0;
  const toLocalTime = value=>{
    const raw = Number(value || 0);
    return Number.isFinite(raw) && raw > 0 ? raw + clockOffset : 0;
  };

  const activeUntil = Math.max(0, toLocalTime(status.activeUntil));
  if(activeUntil <= localNow) return {expired:true};

  const chargeMs = Math.max(1, Number(status.chargeMs || 3_000));
  const chargeSegments = Math.max(1, Number(status.chargeSegments || 3));
  let chargeStartedAt = Math.max(0, toLocalTime(status.chargeStartedAt));
  let chargeReadyAt = Math.max(0, toLocalTime(status.chargeReadyAt));
  if(chargeReadyAt <= 0 && chargeStartedAt > 0) chargeReadyAt = chargeStartedAt + chargeMs;
  if(chargeStartedAt <= 0 && chargeReadyAt > 0) chargeStartedAt = chargeReadyAt - chargeMs;
  if(chargeStartedAt <= 0) chargeStartedAt = localNow;
  if(chargeReadyAt <= 0) chargeReadyAt = chargeStartedAt + chargeMs;

  return {
    abilityId:"spectral_double_shot",
    shipId,
    activeUntil,
    chargeMs,
    chargeSegments,
    chargeStartedAt,
    chargeReadyAt,
    receivedAt:localAnchor
  };
}

export function createCombatServerEventSystem({
  multiplayer,
  getState,
  setState,
  cargo,
  beams,
  rewards,
  panels,
  damagePlayer,
  applyPlayerPoison,
  applyPlayerSlow,
  clearPoison,
  clearSlow,
  pushDamageText,
  spawnPortalExit,
  showToast,
  updateHud,
  updateLootPopup,
  portalStartingLives,
  onPortalMapLoaded = ()=>{},
  applyServerDeath,
  applyServerRespawn,
  markAuthoritativeDamageReceived,
  confirmAuthoritativeShot = ()=>false,
  rejectAuthoritativeShot = ()=>false
}){
  const processedRewardIds = new Set();
  function getCurrentMapToken(map){
    return String(map?.id ?? map?.name ?? "");
  }

  function localWallTimeFromEvent(event = {}){
    const receivedAt = Number(event?.receivedAt);
    if(Number.isFinite(receivedAt)){
      return Date.now() - Math.max(0, performance.now() - receivedAt);
    }
    return Date.now();
  }

  function updateSpectralDoubleShotCharge(status = {}, ownerId = "", eventMeta = status){
    const {player, store} = getState();
    if(!player) return false;
    const activeShipId = String(store?.state?.activeShip || "");
    const now = Date.now();
    const normalized = normalizeSpectralDoubleShotChargeStatus(status, {
      ownerId,
      playerId:multiplayer.playerId,
      activeShipId,
      now,
      localReceivedAt:localWallTimeFromEvent(eventMeta),
      serverAt:eventMeta?.at || status?.at
    });
    if(!normalized) return false;
    if(normalized.expired){
      delete player.spectralDoubleShotCharge;
      return false;
    }
    player.spectralDoubleShotCharge = normalized;
    return true;
  }

  function updateEliteLaserCharges(event = {}){
    if(String(event?.attackerId || "") !== String(multiplayer.playerId || "")) return false;
    const {player} = getState();
    if(!player) return false;
    const state = event.eliteLaser;
    if(!state || typeof state !== "object"){
      delete player.eliteLaserCharges;
      return false;
    }
    player.eliteLaserCharges = {
      ...state,
      receivedAt:Date.now()
    };
    return true;
  }

  const remoteWeaponEvents = createRemoteWeaponEventProcessor({
    multiplayer,
    getState,
    beams,
    getCurrentMapToken
  });
  const questEvents = createQuestServerEventProcessor({
    multiplayer,
    rewards,
    showToast,
    getProfileState:()=>getState()?.store?.state || null
  });

  function loadPortalArena(event){
    const portal = portals.find(p=>p.id === event?.portal?.id) || event?.portal || portals[0];
    const currentMap = createPortalMap(portal);
    const environment = buildPortalEnvironment(portal.id, currentMap);
    const {player, missileSalvos} = getState();
    const authoritativeLives = multiplayer.portalInstance?.lives;
    cargo.clear();
    player.x = Number(event?.spawn?.x ?? currentMap.spawn.x ?? 0);
    player.y = Number(event?.spawn?.y ?? currentMap.spawn.y ?? 0);
    player.vx = 0;
    player.vy = 0;
    player.enginePower = 0;
    player.safeZoneLock = SAFE_ZONE_DELAY;
    missileSalvos.clear();
    beams.clear();
    setState({
      gameMode:"portal",
      activePortal:portal,
      portalWave:Math.max(1, Number(event?.wave || 1)),
      portalDelay:0,
      portalCompleted:false,
      portalLives:typeof authoritativeLives === "number" && Number.isFinite(authoritativeLives)
        ? Math.max(0, Math.min(portalStartingLives, Math.round(authoritativeLives)))
        : portalStartingLives,
      portalAlly:null,
      portalBeacons:[],
      portalObjective:multiplayer.portalObjective || event?.objective || null,
      portalCinematic:null,
      currentMap,
      enemies:[],
      asteroids:environment.asteroids,
      stars:environment.stars,
      dust:environment.dust,
      nebulae:environment.nebulae,
      moveTarget:null,
      selectedEnemy:null,
      bullets:[],
      impactEffects:[],
      particles:[],
      damageTexts:[],
      teleportLock:1.2
    });
    onPortalMapLoaded(currentMap);
    panels.closeSpawnPanel();
    if(!event?.resumed) showToast(`Entree dans ${portal.name}.`);
    updateHud();
  }

  function applyPortalEvents(){
    if(multiplayer.portalStartEvents?.length){
      const event = multiplayer.portalStartEvents.pop();
      multiplayer.portalStartEvents = [];
      loadPortalArena(event);
    }
    if(!multiplayer.portalCompleteEvents?.length) return;
    const events = multiplayer.portalCompleteEvents.splice(0);
    for(const event of events){
      const {activePortal, portalCompleted} = getState();
      const portal = portals.find(p=>p.id === event?.portal?.id) || event?.portal || activePortal;
      if(!portal || portalCompleted) continue;
      setState({activePortal:portal, portalCompleted:true});
      const reward = event.reward || {};
      const xp = Math.max(0, Math.round(Number(reward.xp || 0)));
      if(portal.id !== "ricky") spawnPortalExit();
      const ammoRewards = [
        ...(reward.ammoX4 ? [`+${fmt(reward.ammoX4)} munitions x4`] : []),
        ...(reward.ammoX6 ? [`+${fmt(reward.ammoX6)} munitions x6`] : [])
      ];
      const itemDrop = reward.itemDrop || null;
      const rewardItem = itemDrop?.awarded
        ? equipment.find(item=>item.id === itemDrop.itemId)
        : null;
      const itemRewards = rewardItem
        ? [`+1 ${rewardItem.name}${itemDrop.guaranteed === true ? " (première victoire garantie)" : ""}`]
        : [];
      window.dispatchEvent(new CustomEvent("voidsector:combat-log", {detail:{
        kind:"portal",
        enemyName:`Portail : ${portal.name}`,
        label:["Récompense de portail", ...ammoRewards, ...itemRewards].join(" - "),
        credits:Math.max(0, Math.round(Number(reward.credits || 0))),
        xp,
        premium:Math.max(0, Math.round(Number(reward.premium || 0))),
        at:event.at || Date.now()
      }}));
      rewards.showLootNotice({
        message:"Portail serveur termine",
        credits:reward.credits || 0,
        xp,
        premium:reward.premium || 0,
        ammo:ammoRewards,
        items:itemRewards,
        duration:15
      });
      showToast(portal.id === "ricky"
        ? `${portal.name} termine. Retour automatique dans 15 secondes.`
        : `${portal.name} termine cote serveur.`);
      updateHud();
    }
  }

  function applyRickyCinematicEvents(){
    if(!multiplayer.rickyCinematicEvents?.length) return;
    const event = multiplayer.rickyCinematicEvents.pop();
    multiplayer.rickyCinematicEvents = [];
    setState({
      portalCinematic:{
        target:event?.target || {x:0, y:-520},
        message:event?.message || "A l'aiiiideeee !!",
        durationMs:Number(event?.durationMs || 5600),
        startedAt:performance.now()
      },
      moveTarget:null,
      mouseMoveHeld:false
    });
    showToast("La breche centrale est ouverte.");
  }

  function applyDamageEvents(){
    if(!multiplayer.playerDamageEvents?.length) return;
    const queuedDamageEvents = multiplayer.playerDamageEvents.length;
    countCombatProfiler("events.playerDamage.queued", queuedDamageEvents);
    const {player, currentMap} = getState();
    const remaining = [];
    let normalDamageText = 0;
    let poisonDamageText = 0;
    let latestVitals = null;
    let latestVitalsOrder = -Infinity;
    for(let index = 0; index < multiplayer.playerDamageEvents.length; index += 1){
      const event = multiplayer.playerDamageEvents[index];
      if(String(event.mapId ?? "") !== getCurrentMapToken(currentMap)){
        remaining.push(event);
        continue;
      }
      if(player.isDead) continue;
      const amount = Math.max(0, Math.round(Number(event.amount || 0)));
      if(amount <= 0) continue;
      const serverHp = Number(event.hp);
      const serverMaxHp = Number(event.maxHp);
      const serverShield = Number(event.shield);
      const serverMaxShield = Number(event.maxShield);
      const hasServerVitals = Number.isFinite(serverHp) || Number.isFinite(serverShield);
      const serverOrder = Number.isFinite(Number(event.at))
        ? Number(event.at)
        : Number.isFinite(Number(event.receivedAt)) ? Number(event.receivedAt) : index;
      if(hasServerVitals && serverOrder >= latestVitalsOrder){
        latestVitalsOrder = serverOrder;
        latestVitals = {serverHp, serverMaxHp, serverShield, serverMaxShield};
      }
      const serverAgeMs = Number.isFinite(Number(event.at)) ? Date.now() - Number(event.at) : 0;
      const staleVisual = serverAgeMs > 2500;
      if(staleVisual && hasServerVitals) continue;
      const poison = event.damageType === "poison";
      if(poison) poisonDamageText += amount;
      else normalDamageText += amount;
    }
    const totalDamage = normalDamageText + poisonDamageText;
    setCombatProfilerMetric("events.playerDamage.total", totalDamage);
    setCombatProfilerMetric("events.playerDamage.normalAmount", normalDamageText);
    setCombatProfilerMetric("events.playerDamage.poisonAmount", poisonDamageText);
    if(totalDamage > 0){
      if(latestVitals && typeof markAuthoritativeDamageReceived === "function"){
        markAuthoritativeDamageReceived({
          amount:totalDamage,
          normalDamage:normalDamageText,
          poisonDamage:poisonDamageText
        });
      }else if(latestVitals){
        damagePlayer(totalDamage, {
          recordQuestHpLoss:false,
          allowDamageToHp:false,
          suppressDeath:true,
          serverAuthoritative:true
        });
      }else{
        if(normalDamageText > 0) damagePlayer(normalDamageText, {
          recordQuestHpLoss:false,
          suppressDeath:true,
          serverAuthoritative:true
        });
        if(poisonDamageText > 0) damagePlayer(poisonDamageText, {
          recordQuestHpLoss:false,
          bypassShield:true,
          allowDamageToHp:false,
          suppressDeath:true,
          serverAuthoritative:true
        });
      }
    }
    if(latestVitals){
      const {serverHp, serverMaxHp, serverShield, serverMaxShield} = latestVitals;
      if(Number.isFinite(serverMaxHp) && serverMaxHp > 0) player.maxHp = serverMaxHp;
      if(Number.isFinite(serverHp)) player.hp = Math.max(0, Math.min(player.maxHp || serverHp, serverHp));
      if(Number.isFinite(serverMaxShield) && serverMaxShield >= 0) player.maxShield = serverMaxShield;
      if(Number.isFinite(serverShield)) player.shield = Math.max(0, Math.min(player.maxShield || serverShield, serverShield));
    }
    if(normalDamageText > 0){
      pushDamageText({
        x:player.x,
        y:player.y - 58,
        value:normalDamageText,
        color:"rgba(248,113,113,",
        shadowColor:"rgba(248,113,113,.78)"
      });
    }
    if(poisonDamageText > 0){
      pushDamageText({
        x:player.x,
        y:player.y - (normalDamageText > 0 ? 78 : 58),
        value:`-${poisonDamageText}`,
        color:"rgba(74,222,128,",
        shadowColor:"rgba(34,197,94,.78)"
      });
    }
    multiplayer.playerDamageEvents = remaining;
    countCombatProfiler("events.playerDamage.processed", queuedDamageEvents - remaining.length);
    if(normalDamageText > 0) countCombatProfiler("events.playerDamage.normalText", 1);
    if(poisonDamageText > 0) countCombatProfiler("events.playerDamage.poisonText", 1);
  }

  function applyShipAbilityEffectEvents(){
    if(!multiplayer.shipAbilityEffectEvents?.length) return;
    const {currentMap, particles, player} = getState();
    const remaining = [];
    for(const event of multiplayer.shipAbilityEffectEvents.splice(0)){
      if(String(event.mapId ?? "") !== getCurrentMapToken(currentMap)){
        remaining.push(event);
        continue;
      }
      if(event.kind === "poison_bomb_pulse"){
        const duration = Math.max(.25, Number(event.durationMs || 760) / 1000);
        const followsLocalPlayer = Boolean(event.followSource && player) && String(event.sourceId || "") === String(multiplayer.playerId || "");
        particles.push({
          kind:"poisonWave",
          x:followsLocalPlayer ? player.x : Number(event.x || 0),
          y:followsLocalPlayer ? player.y : Number(event.y || 0),
          offsetX:0,
          offsetY:0,
          followPlayer:followsLocalPlayer,
          life:duration,
          max:duration,
          size:Math.max(40, Number(event.radius || 300)),
          color:"rgba(34,197,94,.72)",
          pulseIndex:Number(event.pulseIndex || 1)
        });
      }
    }
    multiplayer.shipAbilityEffectEvents = remaining;
  }

  function applyShipAbilityStateEvents(){
    if(!multiplayer.shipAbilityEvents?.length) return;
    for(const event of multiplayer.shipAbilityEvents.splice(0)){
      updateSpectralDoubleShotCharge(event);
    }
    multiplayer.shipAbilityEvents = [];
  }

  function applyLifecycleEvents(){
    const {player} = getState();
    let warned = Boolean(getState().radiationWarned);
    for(const event of multiplayer.playerRadiationEvents?.splice(0) || []){
      player.radiationTimer = Math.max(0, Number(event.remainingSeconds ?? 30));
      if(event.active && !warned){
        warned = true;
        setState({radiationWarned:true});
        showToast("Zone irradiee : retourne dans la carte ou ton vaisseau sera detruit.");
      }else if(event.active === false){
        warned = false;
        player.radiationTimer = 30;
        setState({radiationWarned:false});
      }
    }
    for(const event of multiplayer.playerDeathEvents?.splice(0) || []) applyServerDeath?.(event);
    for(const event of multiplayer.playerRespawnEvents?.splice(0) || []) applyServerRespawn?.(event);
    for(const event of multiplayer.portgunEvents?.splice(0) || []){
      if(event?.type === "started"){
        const durationMs = Math.max(1, Number(event.durationMs || 20000));
        setState({
          portgunChannel:{
            teleportId:event.id,
            targetMapId:event.targetMapId,
            targetMapName:event.targetMapName || "secteur",
            durationMs,
            completeAt:Number(event.completeAt || Date.now() + durationMs)
          }
        });
        showToast(`Portgun charge vers ${event.targetMapName || "secteur"} : ne bouge pas pendant ${Math.ceil(Number(event.durationMs || 0) / 1000)}s.`);
      }else if(event?.type === "cancelled"){
        setState({portgunChannel:null});
        showToast(event.message || "Teleportation Portgun annulee.");
      }else if(event?.type === "complete"){
        setState({portgunChannel:null});
        showToast(event.message || "Teleportation Portgun effectuee.");
        applyServerRespawn?.(event);
      }
    }
  }

  function applyStatusEffectEvents(){
    if(!multiplayer.playerStatusEffectEvents?.length) return;
    const latestByType = new Map();
    for(const event of multiplayer.playerStatusEffectEvents.splice(0)){
      if(event?.type) latestByType.set(String(event.type), event);
    }
    for(const event of latestByType.values()){
      if(event?.type === "poison"){
        if(event.active === false) clearPoison?.();
        else applyPlayerPoison?.({...event, serverAuthoritative:true});
      }else if(event?.type === "slow"){
        if(event.active === false) clearSlow?.();
        else applyPlayerSlow?.({...event, serverAuthoritative:true});
      }
    }
  }

  function applyNpcDamageEvents(){
    if(!multiplayer.npcDamageEvents?.length) return;
    const {currentMap, portalAlly} = getState();
    const remaining = [];
    for(const event of multiplayer.npcDamageEvents.splice(0)){
      if(String(event.mapId ?? "") !== getCurrentMapToken(currentMap)){
        remaining.push(event);
        continue;
      }
      if(event.targetId === "ricky_companion" && portalAlly){
        portalAlly.hp = Math.max(0, Number(event.hp ?? portalAlly.hp ?? 0));
        portalAlly.shield = Math.max(0, Number(event.shield ?? portalAlly.shield ?? 0));
        portalAlly.alive = portalAlly.hp > 0;
        pushDamageText({
          x:Number(portalAlly.x || 0),
          y:Number(portalAlly.y || 0) - 58,
          value:getNpcDamageDisplayAmount(event),
          color:"rgba(248,113,113,",
          shadowColor:"rgba(248,113,113,.78)"
        });
      }
    }
    multiplayer.npcDamageEvents = remaining;
  }

  function spawnAbsorbingFireEffect({particles, player, event}){
    if(event.sourceId !== "absorbing_fire" || event.weaponClass !== "laser") return;
    const fromX = Number(event.fromX);
    const fromY = Number(event.fromY);
    if(!Number.isFinite(fromX) || !Number.isFinite(fromY)) return;
    const dx = Number(player.x || 0) - fromX;
    const dy = Number(player.y || 0) - fromY;
    const distance = Math.hypot(dx, dy);
    if(distance < 4) return;
    for(let index = 0; index < 10; index++){
      const progress = .08 + index / 12 * .58;
      const life = .30 + (1 - progress) * .34;
      const jitter = (index % 2 ? 1 : -1) * (4 + index % 3 * 2);
      const normalX = -dy / distance;
      const normalY = dx / distance;
      const x = fromX + dx * progress + normalX * jitter;
      const y = fromY + dy * progress + normalY * jitter;
      particles.push({
        kind:"absorptionOrb",
        x,
        y,
        vx:(Number(player.x || 0) - x) / life,
        vy:(Number(player.y || 0) - y) / life,
        life,
        max:life,
        size:3.2 + index % 3 * 1.25,
        color:index % 3 === 0 ? "rgba(220,252,231,.96)" : "rgba(74,222,128,.88)"
      });
    }
    particles.push({
      kind:"absorptionPulse",
      x:Number(player.x || 0),
      y:Number(player.y || 0),
      offsetX:0,
      offsetY:0,
      vx:0,
      vy:0,
      followPlayer:true,
      life:.48,
      max:.48,
      size:46,
      color:"rgba(74,222,128,.9)"
    });
  }

  function applyPlayerHealEvents(){
    if(!multiplayer.playerHealEvents?.length) return;
    const {player, currentMap, portalAlly, particles} = getState();
    const remaining = [];
    for(const event of multiplayer.playerHealEvents.splice(0)){
      if(String(event.mapId ?? "") !== getCurrentMapToken(currentMap)){
        remaining.push(event);
        continue;
      }
      const amount = Math.max(0, Math.round(Number(event.amount || 0)));
      if(event.targetId === multiplayer.playerId){
        if(Number.isFinite(Number(event.maxHp)) && Number(event.maxHp) > 0) player.maxHp = Number(event.maxHp);
        if(Number.isFinite(Number(event.hp))) player.hp = Math.max(0, Math.min(player.maxHp || Number(event.hp), Number(event.hp)));
        pushDamageText({
          x:player.x,
          y:player.y - 62,
          value:`+${amount}`,
          color:"rgba(74,222,128,",
          shadowColor:"rgba(34,197,94,.78)"
        });
        spawnAbsorbingFireEffect({particles, player, event});
      }else if(event.targetId === "ricky_companion" && portalAlly){
        if(Number.isFinite(Number(event.maxHp)) && Number(event.maxHp) > 0) portalAlly.maxHp = Number(event.maxHp);
        if(Number.isFinite(Number(event.hp))) portalAlly.hp = Math.max(0, Math.min(portalAlly.maxHp || Number(event.hp), Number(event.hp)));
        portalAlly.alive = portalAlly.hp > 0;
        pushDamageText({
          x:Number(portalAlly.x || event.x || 0),
          y:Number(portalAlly.y || event.y || 0) - 62,
          value:`+${amount}`,
          color:"rgba(74,222,128,",
          shadowColor:"rgba(34,197,94,.78)"
        });
      }
    }
    multiplayer.playerHealEvents = remaining;
  }

  function applyEnemyAttackEvents(){
    if(!multiplayer.enemyAttackEvents?.length) return;
    const queuedAttackEvents = multiplayer.enemyAttackEvents.length;
    countCombatProfiler("events.enemyAttack.queued", queuedAttackEvents);
    const {player, currentMap, enemies, bullets, particles} = getState();
    const remaining = [];
    const enemiesById = new Map(enemies.map(enemy=>[String(enemy.id), enemy]));
    let activeServerProjectiles = bullets.reduce((count, bullet)=>count + (bullet.owner === "serverEnemy" ? 1 : 0), 0);
    let spawnedServerProjectiles = 0;
    let spawnedAttackParticles = 0;
    for(const event of multiplayer.enemyAttackEvents){
      if(String(event.mapId ?? "") !== getCurrentMapToken(currentMap)){
        remaining.push(event);
        continue;
      }
      if(event.targetId && String(event.targetId) !== String(multiplayer.playerId)) continue;
      const enemy = enemiesById.get(String(event.enemyId || event.sourceId));
      if(enemy){
        enemy.attackT = Math.max(Number(enemy.attackT || 0), Number(event.life || .22));
        enemy.recentHitTimer = Math.max(Number(enemy.recentHitTimer || 0), .35);
      }
      if(isCombatProfilerFlagEnabled("hideEnemyAttackVisuals")){
        continue;
      }
      if(activeServerProjectiles >= MAX_SERVER_ENEMY_PROJECTILES
        || spawnedServerProjectiles >= MAX_SERVER_ENEMY_PROJECTILES_PER_FRAME){
        continue;
      }
      const fromX = Number(event.fromX ?? enemy?.x ?? player.x);
      const fromY = Number(event.fromY ?? enemy?.y ?? player.y);
      const toX = Number(event.toX ?? player.x);
      const toY = Number(event.toY ?? player.y);
      const distance = Math.hypot(toX - fromX, toY - fromY) || 1;
      const speed = Math.max(120, Number(event.projectileSpeed || enemy?.projectileSpeed || 600));
      const serverTravelTime = Number(event.travelTime);
      bullets.push(createProjectile({
        owner:"serverEnemy",
        startX:fromX,
        startY:fromY,
        targetId:"player",
        damage:0,
        travelTime:Number.isFinite(serverTravelTime)
          ? Math.max(.11, Math.min(1.15, serverTravelTime))
          : Math.max(.11, Math.min(1.15, distance / speed + .06)),
        radius:5,
        color:event.color || enemy?.color || "rgba(248,113,113,.95)",
        particle:event.particle || enemy?.particle || "rgba(252,165,165,.75)",
        sourceId:event.enemyId || event.sourceId,
        hitChance:1,
        visualOnly:true
      }));
      activeServerProjectiles += 1;
      spawnedServerProjectiles += 1;
      countCombatProfiler("events.enemyAttack.projectiles", 1);
      if(spawnedAttackParticles < MAX_SERVER_ENEMY_ATTACK_PARTICLES_PER_FRAME){
        particles.push({kind:"enemyAttack",x:fromX, y:fromY, life:.16, max:.16, size:16, color:event.particle || enemy?.particle || "rgba(252,165,165,.72)"});
        spawnedAttackParticles += 1;
        countCombatProfiler("events.enemyAttack.particles", 1);
      }
    }
    multiplayer.enemyAttackEvents = remaining;
    countCombatProfiler("events.enemyAttack.processed", queuedAttackEvents - remaining.length);
    setCombatProfilerMetric("events.enemyAttack.activeProjectiles", activeServerProjectiles);
    setCombatProfilerMetric("events.enemyAttack.spawnedProjectiles", spawnedServerProjectiles);
    setCombatProfilerMetric("events.enemyAttack.spawnedParticles", spawnedAttackParticles);
  }

  function applyRemoteWeaponEvents(){
    remoteWeaponEvents.applyRemoteWeaponEvents();
  }

  function applyCombatShotEvents(){
    if(!multiplayer.combatShotEvents?.length) return;
    const {store} = getState();
    if(!Array.isArray(multiplayer.remoteEffects)) multiplayer.remoteEffects = [];
    for(const event of multiplayer.combatShotEvents.splice(0)){
      if(String(event?.attackerId || "") === String(multiplayer.playerId || "")){
        confirmAuthoritativeShot(event);
      }
      applyAuthoritativeCombatAmmo({
        event,
        playerId:multiplayer.playerId,
        ammoInventory:store?.state?.ammoInventory
      });
      const serverAt = Number(event?.at || 0);
      if(serverAt > 1_000_000_000_000 && Date.now() - serverAt > COMBAT_VISUAL_MAX_AGE_MS) continue;
      multiplayer.remoteEffects.push({
        ...event,
        kind:String(event.kind || event.weaponClass || "laser"),
        travelTime:Number.isFinite(Number(event.travelTime))
          ? Number(event.travelTime)
          : Math.max(0, Number(event.travelTimeMs || 0)) / 1000,
        sourceId:String(event.attackerId || event.sourceId || ""),
        targetId:String(event.targetId || event.enemyId || ""),
        createdAt:Date.now()
      });
    }
    if(multiplayer.remoteEffects.length > 80){
      multiplayer.remoteEffects.splice(0, multiplayer.remoteEffects.length - 80);
    }
  }

  function applyCombatRejectedEvents(){
    if(!multiplayer.combatRejectedEvents?.length) return;
    for(const event of multiplayer.combatRejectedEvents.splice(0)){
      rejectAuthoritativeShot(event);
    }
  }

  function rickyMuzzlePoint(ally, targetX, targetY, weaponClass){
    const angle = Math.atan2(targetY - Number(ally.y || 0), targetX - Number(ally.x || 0));
    const facing = angle + Math.PI / 2;
    ally.clientAimAngle = facing;
    ally.clientAimUntil = performance.now() + (weaponClass === "rocket" ? 520 : 260);
    const side = weaponClass === "rocket" ? (Math.random() > .5 ? -18 : 18) : 0;
    const front = weaponClass === "rocket" ? 50 : 44;
    return {
      x:Number(ally.x || 0) + Math.cos(angle) * front + Math.cos(facing) * side,
      y:Number(ally.y || 0) + Math.sin(angle) * front + Math.sin(facing) * side,
      angle,
      facing
    };
  }

  function addRickyAttackVisual(event){
    if(String(event?.attackerId || "") !== RICKY_ALLY_ID) return;
    const {portalAlly, bullets, particles} = getState();
    if(!portalAlly || portalAlly.alive === false || Number(portalAlly.hp || 0) <= 0) return;
    const toX = Number(event.x || portalAlly.x || 0);
    const toY = Number(event.y || portalAlly.y || 0);
    const weaponClass = String(event.weaponClass || "laser");
    const muzzle = rickyMuzzlePoint(portalAlly, toX, toY, weaponClass);
    if(weaponClass === "rocket"){
      const distance = Math.hypot(toX - muzzle.x, toY - muzzle.y);
      const bullet = createProjectile({
        owner:"player",
        startX:muzzle.x,
        startY:muzzle.y,
        targetId:String(event.enemyId || ""),
        damage:0,
        travelTime:Math.max(.18, Math.min(.85, distance / 760)),
        radius:10,
        color:"rgba(125,211,252,.95)",
        particle:"rgba(96,165,250,.82)",
        kind:"rocket",
        sprite:RICKY_ROCKET_PROJECTILE,
        visualOnly:true,
        ammoId:"rocket_r2"
      });
      bullet.fixedTarget = {x:toX, y:toY, hp:1};
      bullets.push(bullet);
      particles.push({kind:"muzzle",x:muzzle.x, y:muzzle.y, life:.24, max:.24, size:26, color:"rgba(125,211,252,.78)"});
      return;
    }
    beams.add({
      ammoId:"ricky_laser",
      fromX:muzzle.x,
      fromY:muzzle.y,
      toX,
      toY,
      targetId:String(event.enemyId || ""),
      canReplay:false,
      blueLaser:true
    });
    particles.push({kind:"muzzle",x:muzzle.x, y:muzzle.y, life:.16, max:.16, size:18, color:"rgba(125,211,252,.72)"});
  }

  function addSpectralDoubleShotVisual(event, enemy = null){
    if(String(event?.doubleStrike?.abilityId || "") !== "spectral_double_shot") return;
    if(String(event.weaponClass || "") !== "laser") return;
    updateSpectralDoubleShotCharge(event.doubleStrike, event.attackerId, event);
    const {player, particles} = getState();
    const toX = Number(enemy?.x ?? event.x);
    const toY = Number(enemy?.y ?? event.y);
    if(!Number.isFinite(toX) || !Number.isFinite(toY)) return;
    const fallbackFromX = Number(player?.x || 0);
    const fallbackFromY = Number(player?.y || 0);
    const fromX = Number.isFinite(Number(event.fromX)) ? Number(event.fromX) : fallbackFromX;
    const fromY = Number.isFinite(Number(event.fromY)) ? Number(event.fromY) : fallbackFromY;
    const dx = toX - fromX;
    const dy = toY - fromY;
    const distance = Math.hypot(dx, dy) || 1;
    const normalX = -dy / distance;
    const normalY = dx / distance;
    for(const offset of [-5, 5]){
      beams.add({
        ammoId:event.ammoId || "ammo_x1",
        fromX:fromX + normalX * offset,
        fromY:fromY + normalY * offset,
        toX:toX + normalX * offset * .35,
        toY:toY + normalY * offset * .35,
        targetId:String(event.enemyId || ""),
        canReplay:false,
        variant:"spectral_double_shot",
        widthScale:1.85,
        duration:.28,
        beamLength:190
      });
    }
    particles.push({kind:"muzzle",x:fromX, y:fromY, life:.24, max:.24, size:28, color:"rgba(168,85,247,.82)"});
    particles.push({kind:"impact",x:toX, y:toY, life:.22, max:.22, size:30, color:"rgba(217,70,239,.76)"});
  }

  function applyCombatHitEvents(){
    if(!multiplayer.combatEvents?.length) return;
    const {enemies, store} = getState();
    const events = multiplayer.combatEvents.splice(0);
    const remaining = [];
    const textGroups = [];
    function hitEventOrder(event, fallback){
      const at = Number(event?.at);
      if(Number.isFinite(at) && at > 0) return at;
      const receivedAt = Number(event?.receivedAt);
      return Number.isFinite(receivedAt) ? receivedAt : fallback;
    }
    function queueCombatText(event, target, fallbackOrder){
      if(event?.accepted === false || event?.outcome === "rejected") return;
      const serverAt = Number(event?.at || 0);
      if(serverAt > 1_000_000_000_000 && Date.now() - serverAt > COMBAT_VISUAL_MAX_AGE_MS) return;
      const damage = Math.max(0, Math.round(Number(event.damage || 0)));
      const validMiss = event?.hit === false && Math.max(0, Number(event?.consumed || 0)) > 0;
      if(damage <= 0 && !validMiss) return;
      if(validMiss && String(event?.attackerId || "") !== String(multiplayer.playerId || "")) return;
      const poison = event.damageType === "poison";
      const key = [
        String(event.mapId ?? ""),
        String(event.enemyId || ""),
        String(event.attackerId || event.sourceId || ""),
        poison ? "poison" : "normal"
      ].join(":");
      const order = hitEventOrder(event, fallbackOrder);
      const group = textGroups.find(entry=>
        entry.key === key
        && Math.abs(order - entry.order) <= COMBAT_DAMAGE_TEXT_MERGE_MS
      );
      const next = group || {
        key,
        order,
        x:target.x,
        y:target.y,
        damage:0,
        misses:0,
        poison,
        radius:target.radius
      };
      next.order = Math.min(next.order, order);
      next.x = target.x;
      next.y = target.y;
      next.radius = target.radius;
      if(damage > 0) next.damage += damage;
      else next.misses += 1;
      if(!group) textGroups.push(next);
    }
    for(let index = 0; index < events.length; index += 1){
      const event = events[index];
      if(event?.accepted === false || event?.outcome === "rejected") continue;
      applyAuthoritativeCombatAmmo({
        event,
        playerId:multiplayer.playerId,
        ammoInventory:store?.state?.ammoInventory
      });
      addRickyAttackVisual(event);
      updateEliteLaserCharges(event);
      updateSpectralDoubleShotCharge(event.shipAbilityState, event.attackerId, event);
      const enemy = enemies.find(entry=>String(entry.id) === String(event.enemyId));
      addSpectralDoubleShotVisual(event, enemy);
      if(!enemy){
        const x = Number(event.x);
        const y = Number(event.y);
        if(Number.isFinite(x) && Number.isFinite(y)){
          queueCombatText(event, {
            x,
            y:y - Math.max(16, Number(event.radius || 0) + 16),
            radius:Number(event.radius || 0)
          }, index);
        }else if((performance.now() - Number(event.receivedAt || 0)) < 1000) remaining.push(event);
        continue;
      }
      queueCombatText(event, {
        x:enemy.x,
        y:enemy.y - enemy.radius - 16,
        radius:enemy.radius
      }, index);
    }
    for(const group of textGroups.sort((left, right)=>left.order - right.order)){
      if(group.damage > 0){
        pushDamageText({
          x:group.x,
          y:group.y,
          value:group.poison ? `-${group.damage}` : group.damage,
          ...(group.poison ? {color:"rgba(22,163,74,", shadowColor:"rgba(21,128,61,.82)", life:.92} : {})
        });
      }else{
        pushDamageText({
          x:group.x,
          y:group.y,
          value:"MISS",
          color:"rgba(191,219,254,",
          shadowColor:"rgba(96,165,250,.78)"
        });
      }
    }
    multiplayer.combatEvents = remaining;
  }

  function applyRewardEvents(){
    if(!multiplayer.playerRewardEvents?.length) return;
    const {currentMap, store} = getState();
    const remaining = [];
    for(const event of multiplayer.playerRewardEvents){
      if(String(event.mapId ?? "") !== getCurrentMapToken(currentMap)){
        remaining.push(event);
        continue;
      }
      const rewardId = event.rewardId || `${event.enemyId || "enemy"}:${event.killerId || "killer"}:${event.mapId || "map"}:${event.at || 0}`;
      if(processedRewardIds.has(rewardId)) continue;
      processedRewardIds.add(rewardId);
      if(processedRewardIds.size > 300){
        const oldest = processedRewardIds.values().next().value;
        processedRewardIds.delete(oldest);
      }
      const credits = Math.max(0, Math.round(Number(event.credits || 0)));
      const xp = Math.max(0, Math.round(Number(event.xp || 0)));
      const premium = Math.max(0, Math.round(Number(event.premium || 0)));
      const rewardAppliedByServer = Boolean(event.rewardAppliedByServer);
      const rankPoints = rewardAppliedByServer ? Math.max(0, Number(event.rankPoints || 0)) : 0;
      const reputation = rewardAppliedByServer ? Math.max(0, Math.round(Number(event.reputation || 0))) : 0;
      applyAuthoritativeRewardProgression({event, player:store?.state?.player});
      window.dispatchEvent(new CustomEvent("voidsector:combat-log", {detail:{
        kind:"reward",
        enemyName:event.enemyName || event.enemyType || "Monstre",
        enemyType:event.enemyType || "",
        enemyLevel:event.enemyLevel || 0,
        credits,
        xp,
        premium,
        reputation,
        rankPoints,
        share:event.share || 1,
        at:event.at || Date.now()
      }}));
      rewards.showLootNotice?.({credits, xp, reputation, rankPoints, premium});
      const shareValue = Number(event.share || 1);
      const shareLabel = shareValue < 1 ? ` (partage groupe ${Math.round(shareValue * 100)}%)` : "";
      showToast(`Butin serveur${shareLabel} : +${fmt(credits)} credits${premium ? `, +${fmt(premium)} NOVA` : ""}, +${fmt(xp)} XP, +${fmt(reputation)} reputation.`);
    }
    multiplayer.playerRewardEvents = remaining;
    updateLootPopup();
    updateHud();
  }

  function applyLootDropEvents(){
    if(!multiplayer.lootDropEvents?.length) return;
    const {player, currentMap} = getState();
    const remaining = [];
    for(const event of multiplayer.lootDropEvents){
      if(String(event.mapId ?? "") !== getCurrentMapToken(currentMap)){
        remaining.push(event);
        continue;
      }
      if(event.kind === "portalPiece"){
        const portal = portals.find(item=>item.id === event.portalId);
        if(!portal) continue;
        cargo.spawnPortalPieceDrop(
          {x:Number(event.x || player.x), y:Number(event.y || player.y)},
          portal,
          {
            uid:event.id,
            x:Number(event.x || player.x),
            y:Number(event.y || player.y),
            expiresAt:Number(event.expiresAt || Date.now() + 60000),
            serverControlled:Boolean(event.serverControlled)
          }
        );
        showToast(`${event.name || portal.pieceName || `Fragment ${portal.name}`} détecté au sol.`);
        continue;
      }
      cargo.spawnServerLootDrop?.({
        ...event,
        x:Number(event.x || player.x),
        y:Number(event.y || player.y),
        expiresAt:Number(event.expiresAt || Date.now() + 60000),
        serverControlled:Boolean(event.serverControlled)
      });
      showToast(`${lootNameWithRarityHtml(event)} detecte au sol.`, {trustedHtml:true});
    }
    multiplayer.lootDropEvents = remaining;
  }

  function applyQuestProgressEvents(){
    questEvents.applyQuestProgressEvents();
  }

  function applyQuestClaimEvents(){
    questEvents.applyQuestClaimEvents();
  }

  function applyQuestFailureEvents(){
    questEvents.applyQuestFailureEvents();
  }

  function applyAll(){
    setCombatProfilerMetric("queue.enemyAttack", multiplayer.enemyAttackEvents?.length || 0);
    setCombatProfilerMetric("queue.playerDamage", multiplayer.playerDamageEvents?.length || 0);
    setCombatProfilerMetric("queue.combat", multiplayer.combatEvents?.length || 0);
    setCombatProfilerMetric("queue.reward", multiplayer.playerRewardEvents?.length || 0);
    setCombatProfilerMetric("queue.status", multiplayer.playerStatusEffectEvents?.length || 0);
    timeCombatProfiler("events.combatShot", applyCombatShotEvents);
    timeCombatProfiler("events.combatRejected", applyCombatRejectedEvents);
    timeCombatProfiler("events.remoteWeapons", applyRemoteWeaponEvents);
    timeCombatProfiler("events.enemyAttack", applyEnemyAttackEvents);
    timeCombatProfiler("events.shipAbilityState", applyShipAbilityStateEvents);
    timeCombatProfiler("events.shipAbilityEffect", applyShipAbilityEffectEvents);
    timeCombatProfiler("events.status", applyStatusEffectEvents);
    timeCombatProfiler("events.npcDamage", applyNpcDamageEvents);
    timeCombatProfiler("events.playerDamage", applyDamageEvents);
    timeCombatProfiler("events.playerHeal", applyPlayerHealEvents);
    timeCombatProfiler("events.lifecycle", applyLifecycleEvents);
    timeCombatProfiler("events.combatHit", applyCombatHitEvents);
    timeCombatProfiler("events.reward", applyRewardEvents);
    timeCombatProfiler("events.questClaim", applyQuestClaimEvents);
    timeCombatProfiler("events.lootDrop", applyLootDropEvents);
    timeCombatProfiler("events.questProgress", applyQuestProgressEvents);
    timeCombatProfiler("events.questFailure", applyQuestFailureEvents);
    timeCombatProfiler("events.rickyCinematic", applyRickyCinematicEvents);
    timeCombatProfiler("events.portal", applyPortalEvents);
  }

  return {
    loadPortalArena,
    applyPortalEvents,
    applyRickyCinematicEvents,
    applyCombatRejectedEvents,
    applyDamageEvents,
    applyLifecycleEvents,
    applyCombatShotEvents,
    applyRemoteWeaponEvents,
    applyCombatHitEvents,
    applyRewardEvents,
    applyLootDropEvents,
    applyQuestProgressEvents,
    applyQuestFailureEvents,
    applyAll
  };
}

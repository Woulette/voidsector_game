import { publicAccount } from "./accounts.js";
import { config } from "../config.js";
import { isLoadTestAccount } from "../loadtest/provisionBot.js";
import { assertGameCapacity, publicGameCapacity } from "../players/playerCapacity.js";
import { publicPreparedPortal } from "../portals/portalPreparation.js";

export function createSocketSessionManager({io, players, profileManager, cleanName, emitPlayers, replaceGroupMemberId, resumeQuestTimers, setPlayerMap, syncPlayerLifecycle, syncPlayerStatusEffects, maxConcurrentGamePlayers = 0}){
  function publicAuthPayload({account, session = null}){
    return {
      account,
      token:session?.token || null,
      expiresAt:session?.expiresAt || null
    };
  }

  function attachAccountToSocket(socket, account, session = null){
    const player = players.get(socket.id);
    if(!player || !account) return;
    player.accountId = account.id;
    player.account = account;
    player.name = cleanName(account.username || player.name);
    player.sessionExpiresAt = session?.expiresAt || player.sessionExpiresAt || null;
    socket.emit("account:role", {account:publicAccount(account), at:Date.now()});
    emitPlayers();
  }

  function buildResumeSessionFromState(state, source = "live"){
    if(!state || Number(state.hp || 0) <= 0) return null;
    return {
      source,
      mapId:String(state.mapId ?? "0"),
      x:Number(state.x || 0),
      y:Number(state.y || 0),
      angle:Number(state.angle || 0),
      hp:Math.max(0, Number(state.hp || 0)),
      maxHp:Math.max(0, Number(state.maxHp || state.hp || 0)),
      shield:Math.max(0, Number(state.shield || 0)),
      maxShield:Math.max(0, Number(state.maxShield || state.shield || 0)),
      shipId:String(state.shipId || "unknown"),
      shipImg:String(state.shipImg || ""),
      updatedAt:Math.max(0, Number(state.updatedAt || Date.now()))
    };
  }

  function attachOrResumeAccountSocket(socket, account, session = null){
    const current = players.get(socket.id);
    if(!current || !account) return null;
    if(isLoadTestAccount(account) && !config.loadTest?.enabled){
      socket.emit("auth:error", {
        message:"Les comptes bots de test sont desactives sur ce serveur.",
        at:Date.now()
      });
      socket.disconnect?.(true);
      return null;
    }
    let resumeSession = null;
    const isGameClient = current.clientMode === "game";
    if(isGameClient){
      try{
        assertGameCapacity({
          players,
          accountId:account.id,
          account,
          socketId:socket.id,
          maxConcurrentGamePlayers
        });
      }catch(error){
        if(error?.code === "SERVER_FULL") socket.emit("server:full", publicGameCapacity(error.capacity));
        throw error;
      }
    }
    const duplicates = [...players.values()].filter(player=>player.id !== socket.id && player.accountId === account.id);
    const existing = duplicates.find(player=>player.state) || duplicates[0] || null;
    const transfersExistingState = Boolean(isGameClient && existing?.state);
    if(transfersExistingState){
      resumeSession = buildResumeSessionFromState(existing.state, existing.connected === false ? "reconnect" : "takeover");
      const existingSocket = io.sockets.sockets.get(existing.id);
      const nextPlayer = {
        ...existing,
        id:socket.id,
        accountId:account.id,
        account,
        name:cleanName(account.username || existing.name),
        sessionExpiresAt:session?.expiresAt || existing.sessionExpiresAt || null,
        // Client source metadata belongs to the replaced Socket.IO stream.
        lastClientStateSourceSeq:0,
        lastClientStateRawAt:undefined,
        lastClientStateNormalizedAt:undefined,
        connected:true,
        disconnecting:false,
        logoutPending:null,
        gracefulLogout:false,
        removeAt:0,
        mapRoom:null,
        worldMapSent:false
      };
      if(existing.mapRoom) existingSocket?.leave(existing.mapRoom);
      players.delete(existing.id);
      players.set(socket.id, nextPlayer);
      socket.emit("account:role", {account:publicAccount(account), at:Date.now()});
      if(nextPlayer.groupId) socket.join(nextPlayer.groupId);
      replaceGroupMemberId(existing.id, socket.id);
      existingSocket?.disconnect(true);
      if(nextPlayer.mapId) setPlayerMap(socket, nextPlayer.mapId);
    }else{
      attachAccountToSocket(socket, account, session);
    }
    const duplicatesToRemove = isGameClient
      ? duplicates.filter(duplicate=>duplicate.clientMode === "game")
      : duplicates.filter(duplicate=>duplicate.clientMode !== "game");
    for(const duplicate of duplicatesToRemove){
      if(transfersExistingState && duplicate.id === existing?.id) continue;
      const duplicateSocket = io.sockets.sockets.get(duplicate.id);
      if(duplicate.mapRoom) duplicateSocket?.leave(duplicate.mapRoom);
      replaceGroupMemberId(duplicate.id, socket.id);
      players.delete(duplicate.id);
      duplicateSocket?.disconnect(true);
    }
    if(transfersExistingState || duplicatesToRemove.length){
      emitPlayers();
    }
    const player = players.get(socket.id);
    const persistedProfile = profileManager.getProfileForPlayer?.(player) || null;
    if(player){
      player.firmId = persistedProfile?.player?.firmId || player.account?.firmId || "astra";
      if(persistedProfile) player.preparedPortal = persistedProfile.preparedPortal || null;
    }
    if(isGameClient && !resumeSession){
      resumeSession = buildResumeSessionFromState(profileManager.getWorldSessionForPlayer(player), "profile");
    }
    if(resumeSession){
      setPlayerMap(socket, resumeSession.mapId);
      socket.emit("player:resume", resumeSession);
    }
    if(isGameClient){
      socket.emit("portal:prepared", {
        preparedPortal:publicPreparedPortal(player?.preparedPortal || null),
        synced:true,
        at:Date.now()
      });
    }
    if(isGameClient) resumeQuestTimers?.(player);
    if(isGameClient) syncPlayerStatusEffects?.(player);
    if(isGameClient) syncPlayerLifecycle?.(player);
    return resumeSession;
  }

  function syncProfileForPlayer(socket){
    const player = players.get(socket.id);
    profileManager.syncForSocket(socket, player);
  }

  return {
    attachOrResumeAccountSocket,
    publicAuthPayload,
    syncProfileForPlayer
  };
}

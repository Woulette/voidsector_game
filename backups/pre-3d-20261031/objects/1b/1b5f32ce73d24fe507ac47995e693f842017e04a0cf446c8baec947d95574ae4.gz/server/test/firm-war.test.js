import assert from "node:assert/strict";
import { access, mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import test from "node:test";
import { createFirmWarManager, FIRM_COLLECTIVE_MIN_CONTRIBUTION, FIRM_REWARD_MS, FIRM_SEASON_MS } from "../src/firms/firmWar.js";
import { sanitizeFirmState } from "../src/firms/firmState.js";
import { createWorldRewardManager } from "../src/world/rewards.js";
import { resetFirmRankingBroadcastThrottle } from "../src/firms/firmBroadcasts.js";

function createIoRecorder(){
  const events = [];
  return {
    events,
    io:{
      emit:(event, payload)=>events.push({id:"*", event, payload}),
      to:id=>({
        emit:(event, payload)=>events.push({id, event, payload})
      })
    }
  };
}

test("legacy season rewards recover participant eligibility without granting new accounts", ()=>{
  const now = 50_000;
  const state = sanitizeFirmState({
    rewards:{
      astra:{rank:1, boosters:{damage:.10}, endsAt:now + FIRM_REWARD_MS}
    },
    lastClosedSeason:{
      individualRanking:[
        {key:"account:legacy-participant", firmId:"astra", points:FIRM_COLLECTIVE_MIN_CONTRIBUTION},
        {key:"account:legacy-short", firmId:"astra", points:FIRM_COLLECTIVE_MIN_CONTRIBUTION - 1}
      ]
    }
  }, now);

  assert.equal(state.version, 5);
  assert.equal(state.rewards.astra.eligiblePlayers["account:legacy-participant"], true);
  assert.equal(state.rewards.astra.eligiblePlayers["account:legacy-short"], undefined);
  assert.equal(state.rewards.astra.eligiblePlayers["account:created-later"], undefined);
});

test("firm season stores monster points only for the first-hit owner", async ()=>{
  resetFirmRankingBroadcastThrottle();
  const {events, io} = createIoRecorder();
  const dir = await mkdtemp(join(tmpdir(), "voidsector-firm-war-"));
  const players = new Map([
    ["a", {id:"a", name:"Alpha", connected:true, clientMode:"game", groupId:"g1", mapId:"0", profile:{player:{level:10, firmId:"astra"}}}],
    ["b", {id:"b", name:"Beta", connected:true, clientMode:"game", groupId:"g1", mapId:"0", profile:{player:{level:10, firmId:"cyan"}}}],
    ["c", {id:"c", name:"Gamma", connected:true, clientMode:"game", groupId:"g1", mapId:"1", profile:{player:{level:10, firmId:"astra"}}}]
  ]);
  const groups = new Map([["g1", {id:"g1", members:["a", "b", "c"]}]]);
  try{
    const firmWarManager = createFirmWarManager({file:join(dir, "firmWar.json"), logger:{warn(){}}, now:()=>1000});
    await firmWarManager.load();
    const manager = createWorldRewardManager({
      io,
      players,
      groups,
      firmWarManager,
      profileManager:{
        getProfileForPlayer:player=>player.profile,
        profileKeyForPlayer:player=>`account:${player.id}`,
        applyReward({player}){ return player.profile; }
      },
      emitProfileSync(){}
    });

    manager.emitWorldReward({
      attackerId:"b",
      firmAttackerId:"a",
      mapId:"0",
      enemy:{id:"e1", kind:"sentinel_orb", type:"Orbe", level:5, reward:{credits:100, xp:100, premium:0}}
    });

    const astra = firmWarManager.snapshot().firms.find(firm=>firm.id === "astra");
    const cyan = firmWarManager.snapshot().firms.find(firm=>firm.id === "cyan");
    assert.equal(astra.points, 1);
    assert.equal(cyan.points, 0);
    assert.equal(firmWarManager.snapshot({playerKey:"account:a"}).personal.contribution, 1);
    assert.equal(firmWarManager.snapshot({playerKey:"account:b"}).personal.contribution, 0);
    assert.equal(events.some(entry=>entry.event === "firm:ranking" && entry.id === "*"), true);
  }finally{
    await rm(dir, {recursive:true, force:true});
  }
});

test("firm monster kills throttle global ranking but keep personal season objectives fresh", async ()=>{
  resetFirmRankingBroadcastThrottle();
  const {events, io} = createIoRecorder();
  const dir = await mkdtemp(join(tmpdir(), "voidsector-firm-war-"));
  const player = {id:"a", name:"Alpha", connected:true, clientMode:"game", mapId:"0", profile:{player:{level:10, firmId:"astra"}}};
  const players = new Map([["a", player]]);
  try{
    const firmWarManager = createFirmWarManager({file:join(dir, "firmWar.json"), logger:{warn(){}}, now:()=>1000});
    await firmWarManager.load();
    const manager = createWorldRewardManager({
      io,
      players,
      groups:new Map(),
      firmWarManager,
      profileManager:{
        getProfileForPlayer:entry=>entry.profile,
        profileKeyForPlayer:entry=>`account:${entry.id}`,
        applyReward({player:entry}){ return entry.profile; }
      },
      emitProfileSync(){}
    });

    manager.emitWorldReward({
      attackerId:"a",
      mapId:"0",
      enemy:{id:"e1", kind:"sentinel_orb", type:"Orbe", level:10, reward:{credits:100, xp:100, premium:0}}
    });
    manager.emitWorldReward({
      attackerId:"a",
      mapId:"0",
      enemy:{id:"e2", kind:"sentinel_orb", type:"Orbe", level:10, reward:{credits:100, xp:100, premium:0}}
    });

    assert.equal(events.filter(entry=>entry.event === "firm:ranking" && entry.id === "*").length, 1);
    const personalSnapshots = events.filter(entry=>entry.event === "firm:snapshot" && entry.id === "a");
    assert.equal(personalSnapshots.length, 2);
    assert.equal(Array.isArray(personalSnapshots[1].payload.seasonObjectives), true);
    assert.equal(Object.hasOwn(personalSnapshots[1].payload, "individualRanking"), false);
  }finally{
    await rm(dir, {recursive:true, force:true});
  }
});

test("firm monster points ignore enemies more than eight levels below the rewarded player", async ()=>{
  const {io} = createIoRecorder();
  const dir = await mkdtemp(join(tmpdir(), "voidsector-firm-war-"));
  const players = new Map([
    ["a", {id:"a", name:"Alpha", connected:true, clientMode:"game", mapId:"0", profile:{player:{level:20, firmId:"astra"}}}]
  ]);
  try{
    const firmWarManager = createFirmWarManager({file:join(dir, "firmWar.json"), logger:{warn(){}}, now:()=>1000});
    await firmWarManager.load();
    const manager = createWorldRewardManager({
      io,
      players,
      groups:new Map(),
      firmWarManager,
      profileManager:{
        getProfileForPlayer:player=>player.profile,
        applyReward({player}){ return player.profile; }
      },
      emitProfileSync(){}
    });

    manager.emitWorldReward({
      attackerId:"a",
      mapId:"0",
      enemy:{id:"e-low", kind:"drone_pirate", type:"Drone", level:10, reward:{credits:100, xp:100, premium:0}}
    });

    const astra = firmWarManager.snapshot().firms.find(firm=>firm.id === "astra");
    assert.equal(astra.points, 0);

    manager.emitWorldReward({
      attackerId:"a",
      mapId:"0",
      enemy:{id:"e-threshold", kind:"drone_pirate", type:"Drone", level:12, reward:{credits:100, xp:100, premium:0}}
    });

    const astraAfterThreshold = firmWarManager.snapshot().firms.find(firm=>firm.id === "astra");
    assert.equal(astraAfterThreshold.points, 1);

    manager.emitWorldReward({
      attackerId:"a",
      mapId:"0",
      enemy:{id:"e-higher", kind:"drone_pirate", type:"Drone", level:28, reward:{credits:100, xp:100, premium:0}}
    });

    const astraAfterHigher = firmWarManager.snapshot().firms.find(firm=>firm.id === "astra");
    assert.equal(astraAfterHigher.points, 2);
  }finally{
    await rm(dir, {recursive:true, force:true});
  }
});

test("low level monster kills still progress firm quests without direct firm point", async ()=>{
  const now = new Date(2026, 5, 12, 7).getTime();
  const {io} = createIoRecorder();
  const dir = await mkdtemp(join(tmpdir(), "voidsector-firm-war-low-quest-"));
  const players = new Map([
    ["a", {id:"a", name:"Alpha", connected:true, clientMode:"game", mapId:"0", profile:{player:{level:50, firmId:"astra"}}}]
  ]);
  try{
    const firmWarManager = createFirmWarManager({file:join(dir, "firmWar.json"), logger:{warn(){}}, now:()=>now});
    await firmWarManager.load();
    const manager = createWorldRewardManager({
      io,
      players,
      groups:new Map(),
      firmWarManager,
      profileManager:{
        getProfileForPlayer:player=>player.profile,
        profileKeyForPlayer:()=>"account:a",
        applyReward({player}){ return player.profile; }
      },
      emitProfileSync(){}
    });

    manager.emitWorldReward({
      attackerId:"a",
      mapId:"0",
      enemy:{id:"e-low-orb", kind:"drone_pirate", type:"Orbe", level:1, reward:{credits:100, xp:100, premium:0}}
    });

    const snapshot = firmWarManager.snapshot({playerKey:"account:a", profile:players.get("a").profile});
    const astra = snapshot.firms.find(firm=>firm.id === "astra");
    const quest = snapshot.dailyQuests.find(entry=>entry.definitionId === "orbs");
    const seasonalOrb = snapshot.seasonObjectives.find(entry=>entry.id === "season-solo-orbs-50");
    assert.equal(astra.points, 0);
    assert.equal(snapshot.personal.contribution, 0);
    assert.equal(quest.firms.astra.progress, 1);
    assert.equal(quest.player.contribution, 1);
    assert.equal(seasonalOrb.progress, 1);
  }finally{
    await rm(dir, {recursive:true, force:true});
  }
});

test("firm season closes with seven-day faction boosters", async ()=>{
  let now = 10_000;
  const dir = await mkdtemp(join(tmpdir(), "voidsector-firm-war-"));
  try{
    const manager = createFirmWarManager({file:join(dir, "firmWar.json"), logger:{warn(){}}, now:()=>now});
    await manager.load();
    manager.addFirmPoints("astra", FIRM_COLLECTIVE_MIN_CONTRIBUTION, {key:"account:astra-veteran", name:"Astra Veteran", firmId:"astra"});
    manager.addFirmPoints("astra", FIRM_COLLECTIVE_MIN_CONTRIBUTION - 1, {key:"account:astra-short", name:"Astra Short", firmId:"astra"});
    manager.addFirmPoints("cyan", FIRM_COLLECTIVE_MIN_CONTRIBUTION, {key:"account:cyan-veteran", name:"Cyan Veteran", firmId:"cyan"});
    now += FIRM_SEASON_MS + 1;
    const snapshot = manager.snapshot();
    const astra = snapshot.firms.find(firm=>firm.id === "astra");
    const cyan = snapshot.firms.find(firm=>firm.id === "cyan");
    assert.deepEqual(manager.getActiveBoosters("astra", {}, null, "account:astra-veteran"), {damage:.10, shield:.10, hull:.10, credits:.25, nova:.10});
    assert.deepEqual(manager.getActiveBoosters("astra", {}, null, "account:astra-short"), {});
    assert.deepEqual(manager.getActiveBoosters("cyan", {}, null, "account:cyan-veteran"), {damage:.10, shield:.10, nova:.10});
    assert.deepEqual(manager.getActiveBoosters("astra", {}, null, "account:created-after-season"), {});
    assert.equal(manager.snapshot({playerKey:"account:astra-veteran", profile:{player:{firmId:"astra"}}}).personal.boosters.items.length, 5);
    assert.equal(manager.snapshot({playerKey:"account:astra-short", profile:{player:{firmId:"astra"}}}).personal.boosters.items.length, 0);
    assert.equal(manager.snapshot({playerKey:"account:created-after-season", profile:{player:{firmId:"astra"}}}).personal.boosters.items.length, 0);
    assert.equal(Object.hasOwn(snapshot, "personal"), false);
    assert.equal(astra.rewardEndsAt, now + FIRM_REWARD_MS);
    assert.equal(cyan.rewardRank, 2);
    assert.deepEqual(cyan.activeBoosters, {damage:.10, shield:.10, nova:.10});
  }finally{
    await rm(dir, {recursive:true, force:true});
  }
});

test("faction economy boosters affect credits and NOVA but not XP", ()=>{
  const applied = [];
  const players = new Map([["a", {
    id:"a",
    name:"Alpha",
    connected:true,
    clientMode:"game",
    mapId:"0",
    profile:{player:{level:10, firmId:"astra"}}
  }]]);
  const manager = createWorldRewardManager({
    io:{emit(){}, to:()=>({emit(){}})},
    players,
    groups:new Map(),
    firmWarManager:{
      getActiveBoosters:()=>({credits:.25, nova:.10}),
      addMonsterKillPoints:()=>({})
    },
    profileManager:{
      getProfileForPlayer:player=>player.profile,
      applyCombatReward({player, reward}){
        applied.push(reward);
        return player.profile;
      }
    },
    emitProfileSync(){}
  });

  manager.emitWorldReward({
    attackerId:"a",
    mapId:"0",
    enemy:{id:"boosted-enemy", kind:"eclanite", type:"Eclanite", level:10, reward:{credits:100, xp:100, premium:100}}
  });

  assert.equal(applied[0].credits, 125);
  assert.equal(applied[0].xp, 100);
  assert.equal(applied[0].premium, 110);
});

test("firm points persist in the database without touching the JSON fallback", async ()=>{
  const dir = await mkdtemp(join(tmpdir(), "voidsector-firm-war-db-"));
  const file = join(dir, "firmWar.json");
  let storedState = null;
  const database = {
    async query(text, params = []){
      if(text.includes("SELECT state_json")){
        return {rows:storedState ? [{state_json:storedState}] : []};
      }
      if(text.includes("INSERT INTO firm_war_state")){
        storedState = JSON.parse(params[0]);
        return {rows:[]};
      }
      throw new Error(`Unexpected query: ${text}`);
    }
  };

  try{
    const manager = createFirmWarManager({database, file, logger:{warn(){}}, now:()=>1000});
    await manager.load();
    manager.addFirmPoints("astra", 3);
    await new Promise(resolve=>setTimeout(resolve, 100));

    assert.equal(storedState.points.astra, 3);
    await assert.rejects(access(file), {code:"ENOENT"});
  }finally{
    await rm(dir, {recursive:true, force:true});
  }
});

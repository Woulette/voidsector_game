import { validatePlayerState } from "../players/playerStateValidation.js";
import { buildGlobalLeaderboardSnapshotFromManager } from "../players/leaderboard.js";
import { consumeInventoryItemAmount } from "../economy/inventoryStacks.js";
import { config } from "../config.js";
import { isLoadTestAccount } from "../loadtest/provisionBot.js";
import { checkGameCapacity, publicGameCapacity } from "../players/playerCapacity.js";
import { applyTutorialAction } from "../players/tutorialActions.js";
import { isVitalOnlyStateCorrection, shouldEmitPlayerStateCorrection } from "./stateCorrections.js";
import { confirmProfileSave } from "./profileSaveGuard.js";
import {
  PORTGUN_FLUID_ITEM_ID,
  cancelPendingPortgunTeleport,
  getRandomPortgunDestination,
  hasPortgunTeleportMoved,
  validatePortgunTeleport
} from "../players/portgunTeleport.js";

const LEADERBOARD_BROADCAST_INTERVAL_MS = 15 * 60 * 1000;
let lastLeaderboardBroadcastAt = 0;

export function advancePlayerStateSourceAt({
  hasSourceAt,
  rawSourceAt,
  lastRawSourceAt,
  lastClientNormalizedAt,
  previousSourceAt,
  sourceDelta,
  now
} = {}){
  const previous = Number(previousSourceAt);
  const lastRaw = Number(lastRawSourceAt);
  const lastNormalized = Number(lastClientNormalizedAt);
  const candidate = hasSourceAt
    && Number.isFinite(lastRaw)
    && Number.isFinite(lastNormalized)
    ? lastNormalized + Number(sourceDelta || 0)
    : hasSourceAt
      ? Number(rawSourceAt)
      : Number.isFinite(previous)
        ? previous + Number(sourceDelta || 0)
        : Number(now);
  return Number.isFinite(previous) ? Math.max(previous + 1, candidate) : candidate;
}

export function registerPlayerHandlers(socket, context){
  const {
    cleanName,
    buildFirmSpawnSession,
    emitProfileSync,
    emitPlayers,
    groups,
    guard,
    io,
    logger,
    players,
    presence,
    profileManager,
    firmWarManager,
    publicPlayer,
    replaceGroupMemberId,
    respawnPlayer,
    resumeQuestTimers,
    setPlayerMap,
    syncPlayerLifecycle,
    syncPlayerStatusEffects,
    syncProfileForPlayer,
    maxConcurrentGamePlayers = 0
  } = context;

  function cleanClientId(value){
    return String(value || "").trim().replace(/[^a-zA-Z0-9:_-]/g, "").slice(0, 80);
  }

  function isLocalDebugSocket(){
    if(String(process.env.NODE_ENV || "").toLowerCase() === "production") return false;
    const address = String(socket.handshake?.address || socket.conn?.remoteAddress || "");
    return address === "::1" || address === "127.0.0.1" || address.endsWith(":127.0.0.1");
  }

  function getCurrentProfileKey(){
    const player = players.get(socket.id);
    return profileManager.profileKeyForPlayer?.(player) || "";
  }

  function emitLeaderboard(target = socket, currentKey = getCurrentProfileKey()){
    target?.emit?.("leaderboard:ranking", buildGlobalLeaderboardSnapshotFromManager(profileManager, {currentKey}));
  }

  function emitLeaderboardForAccount(){
    const currentPlayer = players.get(socket.id);
    const accountId = String(currentPlayer?.accountId || "");
    const currentKey = profileManager.profileKeyForPlayer?.(currentPlayer) || "";
    const snapshot = buildGlobalLeaderboardSnapshotFromManager(profileManager, {currentKey});
    const targetIds = accountId
      ? [...new Set([...players.values()]
          .filter(player=>String(player?.accountId || "") === accountId && player?.connected !== false)
          .map(player=>player.id)
          .filter(Boolean))]
      : [];
    if(io?.to && targetIds.length){
      for(const socketId of targetIds) io.to(socketId).emit("leaderboard:ranking", snapshot);
      return;
    }
    socket.emit("leaderboard:ranking", snapshot);
  }

  function broadcastLeaderboard(){
    const now = Date.now();
    if(lastLeaderboardBroadcastAt && now - lastLeaderboardBroadcastAt < LEADERBOARD_BROADCAST_INTERVAL_MS) return;
    lastLeaderboardBroadcastAt = now;
    io?.emit?.("leaderboard:ranking", buildGlobalLeaderboardSnapshotFromManager(profileManager));
  }

  function emitPortgunError(message, extra = {}){
    socket.emit("portgun:error", {message, ...extra, at:Date.now()});
  }

  function cancelPendingPortgun(player, reason = "cancelled", message = "Teleportation annulee."){
    return cancelPendingPortgunTeleport(player, {io, reason, message});
  }

  function finiteNumber(value){
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  function normalizeStateSource(player, payload, previousState, now){
    const hasSequence = Object.hasOwn(payload || {}, "sourceSeq");
    const rawSequence = Number(payload?.sourceSeq);
    if(hasSequence && (!Number.isSafeInteger(rawSequence) || rawSequence <= 0)) return null;
    const storedSequence = Number(player.lastClientStateSourceSeq);
    const lastClientSequence = Number.isSafeInteger(storedSequence) && storedSequence > 0
      ? storedSequence
      : 0;
    const sourceSeq = hasSequence ? rawSequence : lastClientSequence + 1;
    if(sourceSeq <= lastClientSequence || !Number.isSafeInteger(sourceSeq)) return null;

    const hasSourceAt = Object.hasOwn(payload || {}, "sourceAt");
    const rawSourceAt = Number(payload?.sourceAt);
    if(hasSourceAt && (!Number.isFinite(rawSourceAt) || rawSourceAt < 0 || rawSourceAt > Number.MAX_SAFE_INTEGER)){
      return null;
    }
    const lastRawSourceAt = Number(player.lastClientStateRawAt);
    if(hasSourceAt && Number.isFinite(lastRawSourceAt) && rawSourceAt <= lastRawSourceAt) return null;

    const lastStreamAt = Number(player.lastStateStreamAt || previousState?.serverAt || previousState?.updatedAt || now - 50);
    const fallbackDelta = Math.max(1, Math.min(1000, now - lastStreamAt));
    const rawDelta = hasSourceAt && Number.isFinite(lastRawSourceAt)
      ? rawSourceAt - lastRawSourceAt
      : fallbackDelta;
    const sourceDelta = Math.max(1, Math.min(1000, rawDelta));
    const previousSourceAt = Number(previousState?.sourceAt);
    const lastClientNormalizedAt = Number(player.lastClientStateNormalizedAt);
    const sourceAt = advancePlayerStateSourceAt({
      hasSourceAt,
      rawSourceAt,
      lastRawSourceAt,
      lastClientNormalizedAt,
      previousSourceAt,
      sourceDelta,
      now
    });
    const streamSeq = Math.max(0, Number(player.stateStreamSeq || 0)) + 1;
    if(!Number.isSafeInteger(streamSeq)) return null;
    return {
      sourceSeq,
      sourceAt,
      streamSeq,
      serverAt:now,
      rawSourceAt:hasSourceAt ? rawSourceAt : null
    };
  }

  function stateIsMoving(state){
    return Boolean(state?.moveTarget)
      || Math.hypot(Number(state?.vx || 0), Number(state?.vy || 0)) > .5
      || Number(state?.enginePower || 0) > .02;
  }

  function requiresReliableStateBroadcast(player, previous, next, payload, now){
    if(!previous) return true;
    if(now - Number(player.lastReliableStateBroadcastAt || 0) >= 1000) return true;
    if(String(previous.mapId ?? "") !== String(next.mapId ?? "")) return true;
    const visualNext = {...next, vx:payload?.vx, vy:payload?.vy, enginePower:payload?.enginePower};
    if(stateIsMoving(previous) !== stateIsMoving(visualNext)) return true;
    return Math.hypot(
      Number(next.x || 0) - Number(previous.x || 0),
      Number(next.y || 0) - Number(previous.y || 0)
    ) > 240;
  }

  function canEmitWeaponVisual(player, payload, starts){
    if(!player || player.clientMode !== "game" || !player.state) return false;
    if(player.state.isDead || Number(player.state.hp ?? 0) <= 0) return false;
    const mapId = String(player.state.mapId ?? player.mapId ?? "");
    if(!mapId || String(player.mapId ?? "") !== mapId) return false;
    if(payload?.mapId !== undefined && String(payload.mapId) !== mapId) return false;
    if(!player.mapRoom) return false;
    const playerX = Number(player.state.x || 0);
    const playerY = Number(player.state.y || 0);
    return starts.every(start=>
      Number.isFinite(start.x)
      && Number.isFinite(start.y)
      && Math.hypot(start.x - playerX, start.y - playerY) <= 520
    );
  }

  async function completePendingPortgun(playerId, teleportId){
    const player = players.get(playerId);
    if(!player?.pendingPortgunTeleport || player.pendingPortgunTeleport.id !== teleportId) return;
    const pending = player.pendingPortgunTeleport;
    const targetSocket = io?.sockets?.sockets?.get(player.id);
    if(!targetSocket){
      player.pendingPortgunTeleport = null;
      return;
    }
    if(!player.state || Number(player.state.hp ?? 1) <= 0 || player.state.isDead){
      cancelPendingPortgun(player, "dead", "Teleportation annulee : vaisseau detruit.");
      return;
    }
    if(hasPortgunTeleportMoved(pending, player.state)){
      cancelPendingPortgun(player, "moved", "Teleportation annulee : ton vaisseau a bouge.");
      return;
    }

    let validation = null;
    const profileResult = profileManager.updateProfileForPlayer({
      player,
      update:profile=>{
        validation = validatePortgunTeleport({
          player,
          profile,
          targetMapId:pending.targetMapId,
          now:Date.now(),
          allowPending:true
        });
        if(!validation.ok) return validation;
        if(!consumeInventoryItemAmount(profile, PORTGUN_FLUID_ITEM_ID, 1)){
          return {ok:false, reason:"Il faut 1 fluide de teleportation."};
        }
        return {ok:true};
      }
    });
    if(!profileResult.ok || !validation?.ok){
      cancelPendingPortgun(player, "invalid", profileResult.reason || validation?.reason || "Teleportation refusee.");
      return;
    }
    if(!await confirmProfileSave(targetSocket, profileResult, {
      eventName:"portgun:error",
      message:"Sauvegarde temporairement indisponible. Teleportation annulee."
    })){
      cancelPendingPortgun(player, "save-failed", "Teleportation annulee : sauvegarde indisponible.");
      return;
    }

    const destination = getRandomPortgunDestination(validation.map);
    const now = Date.now();
    player.pendingPortgunTeleport = null;
    player.state = {
      ...player.state,
      mapId:String(validation.map.id),
      x:destination.x,
      y:destination.y,
      vx:0,
      vy:0,
      enginePower:0,
      moveTarget:null,
      updatedAt:now,
      source:"portgun"
    };
    player.mapId = String(validation.map.id);
    setPlayerMap(targetSocket, player.state.mapId);
    const savedProfile = profileManager.saveWorldSession({player, state:player.state, force:true}) || profileResult.profile;
    emitProfileSync?.(player, savedProfile);
    targetSocket.emit("portgun:complete", {
      targetMapId:String(validation.map.id),
      targetMapName:validation.map.displayName || validation.map.name,
      consumedItemId:PORTGUN_FLUID_ITEM_ID,
      session:{...player.state},
      message:`Teleportation vers ${validation.map.displayName || validation.map.name} effectuee.`,
      at:now
    });
    emitPlayers();
  }

  function takeoverGuestSocket(player, clientId){
    if(!player || player.accountId || !clientId) return player;
    const existing = [...players.values()].find(candidate=>
      candidate.id !== player.id
      && !candidate.accountId
      && candidate.clientId === clientId
    );
    if(!existing) return player;
    const existingSocket = context.io?.sockets?.sockets?.get(existing.id);
    const nextPlayer = {
      ...existing,
      id:player.id,
      name:player.name,
      clientId,
      clientMode:player.clientMode,
      connected:true,
      disconnecting:false,
      logoutPending:null,
      gracefulLogout:false,
      removeAt:0,
      mapRoom:null,
      worldMapSent:false
    };
    if(existing.mapRoom) existingSocket?.leave(existing.mapRoom);
    players.delete(existing.id);
    players.set(player.id, nextPlayer);
    if(nextPlayer.groupId) socket.join(nextPlayer.groupId);
    replaceGroupMemberId?.(existing.id, player.id);
    existingSocket?.disconnect(true);
    if(nextPlayer.mapId) setPlayerMap(socket, nextPlayer.mapId);
    return nextPlayer;
  }

  socket.on("player:hello", payload=>{
    if(!guard("player:hello")) return;
    let player = players.get(socket.id);
    if(!player) return;
    const requestedClientMode = payload?.clientMode === "game" ? "game" : "launcher";
    if(requestedClientMode === "game" && isLoadTestAccount(player.account) && !config.loadTest?.enabled){
      player.clientMode = "launcher";
      socket.emit("auth:error", {
        message:"Les comptes bots de test sont desactives sur ce serveur.",
        at:Date.now()
      });
      socket.disconnect?.(true);
      emitLeaderboard();
      emitPlayers();
      return;
    }
    if(requestedClientMode === "game" && player.accountId){
      const capacity = checkGameCapacity({
        players,
        accountId:player.accountId,
        account:player.account,
        socketId:player.id,
        maxConcurrentGamePlayers
      });
      if(!capacity.ok){
        player.clientMode = "launcher";
        socket.emit("server:full", publicGameCapacity(capacity));
        socket.emit("auth:error", {message:capacity.message});
        emitLeaderboard();
        emitPlayers();
        return;
      }
    }
    player.clientMode = requestedClientMode;
    player.clientId = cleanClientId(payload?.clientId);
    if(!player.accountId) player.name = cleanName(payload?.name);
    player = takeoverGuestSocket(player, player.clientId);
    if(player.clientMode === "game") presence.markActivity?.(player, "connexion", Date.now());
    const waitingForAuthProfile = Boolean(payload?.hasAuthToken && !player.accountId);
    if(!player.accountId){
      if(player.clientMode === "game" && !waitingForAuthProfile){
        socket.emit("auth:required", {
          eventName:"player:hello",
          message:"Connecte un compte MMO avant d'entrer en jeu.",
          at:Date.now()
        });
      }
      emitLeaderboard();
      return;
    }
    syncProfileForPlayer(socket);
    if(player.clientMode === "game"){
      resumeQuestTimers?.(player);
      syncPlayerStatusEffects?.(player);
      syncPlayerLifecycle?.(player);
    }
    emitLeaderboard();
    emitPlayers();
  });

  socket.on("leaderboard:sync", ()=>{
    if(!guard("leaderboard:sync")) return;
    emitLeaderboardForAccount();
  });

  socket.on("profile:refresh", ()=>{
    if(!guard("profile:refresh")) return;
    const player = players.get(socket.id);
    if(!player?.accountId) return;
    const profile = profileManager.getProfileForPlayer(player);
    if(profile) emitProfileSync?.(player, profile);
  });

  socket.on("profile:save", async payload=>{
    if(!guard("profile:save")) return;
    const player = players.get(socket.id);
    const saveResult = profileManager.saveFromPayload({player, payload});
    const incoming = saveResult?.profile || saveResult;
    const requestId = cleanClientId(payload?.requestId);
    if(!incoming){
      socket.emit("profile:saved", {
        requestId,
        status:"rejected",
        reason:"invalid-profile-save",
        updatedAt:Math.max(0, Number(payload?.profile?.updatedAt || 0)),
        at:Date.now()
      });
      return;
    }
    try{
      await saveResult?.persistence;
    }catch{
      socket.emit("profile:saved", {
        requestId,
        status:"rejected",
        reason:"profile-persistence-failed",
        updatedAt:Math.max(0, Number(payload?.profile?.updatedAt || 0)),
        at:Date.now()
      });
      return;
    }
    if(saveResult?.claimedQuests?.length){
      for(const claim of saveResult.claimedQuests){
        socket.emit("quest:claimed", {
          id:claim.quest?.id,
          title:claim.quest?.title,
          reward:claim.reward || {},
          auto:true,
          at:Date.now()
        });
      }
    }
    socket.emit("profile:saved", {
      requestId,
      status:saveResult?.status || (saveResult?.unchanged ? "unchanged" : "saved"),
      reason:saveResult?.reason || "",
      updatedAt:Math.max(0, Number(saveResult?.acknowledgedAt || payload?.profile?.updatedAt || 0)),
      serverUpdatedAt:Math.max(0, Number(saveResult?.serverUpdatedAt || incoming.updatedAt || 0)),
      actionSlotsUpdatedAt:Math.max(0, Number(saveResult?.actionSlotsUpdatedAt || incoming.actionSlotsUpdatedAt || 0)),
      at:Date.now()
    });
    if(saveResult?.conflict){
      socket.emit("profile:sync", {
        ...incoming,
        profileSyncReason:"profile-save-conflict"
      });
      return;
    }
    if(!saveResult?.unchanged){
      emitProfileSync?.(player, incoming);
      if(saveResult?.claimedQuests?.length) broadcastLeaderboard();
    }
  });

  socket.on("profile:setup", async payload=>{
    if(!guard("profile:setup")) return;
    const player = players.get(socket.id);
    if(!player?.accountId){
      socket.emit("profile:setup-error", {message:"Connecte ton compte avant de choisir ta firme."});
      return;
    }
    let result = null;
    try{
      result = await profileManager.setupProfileForPlayer({
        player,
        name:payload?.name,
        firmId:payload?.firmId
      });
    }catch(error){
      logger?.warn?.("Profile setup failed", {
        playerId:player.id,
        accountId:player.accountId,
        error:error?.message || String(error)
      });
      socket.emit("profile:setup-error", {message:"Configuration du profil temporairement indisponible."});
      return;
    }
    if(!result.ok){
      socket.emit("profile:setup-error", {message:result.reason || "Configuration du profil impossible."});
      return;
    }
    if(result.firmChanged){
      const accountPlayers = [...players.values()].filter(candidate=>candidate.accountId === player.accountId);
      let syncedProfile = result.profile;
      for(const accountPlayer of accountPlayers){
        accountPlayer.firmId = result.firm?.id || result.profile?.player?.firmId || "astra";
        accountPlayer.account = accountPlayer.account ? {...accountPlayer.account, firmId:result.firm?.id} : accountPlayer.account;
        accountPlayer.mapId = String(result.firm?.baseMapId ?? "0");
        if(accountPlayer.clientMode !== "game") continue;
        const spawnSession = {
          ...buildFirmSpawnSession({
            shipId:result.profile?.activeShip,
            firmId:result.firm?.id,
            state:accountPlayer.state
          }),
          source:"firm-change"
        };
        accountPlayer.state = {...spawnSession};
        accountPlayer.mapId = spawnSession.mapId;
        const accountSocket = context.io?.sockets?.sockets?.get(accountPlayer.id);
        if(accountSocket){
          setPlayerMap(accountSocket, spawnSession.mapId);
          accountSocket.emit("player:resume", spawnSession);
        }
        syncedProfile = profileManager.saveWorldSession({
          player:accountPlayer,
          state:accountPlayer.state,
          force:true
        }) || syncedProfile;
      }
      result.profile = syncedProfile;
    }
    socket.emit("profile:setup-complete", {
      name:result.profile?.player?.name,
      firmId:result.profile?.player?.firmId,
      firmLabel:result.firm?.label,
      homeMap:result.firm?.homeMapName,
      at:Date.now()
    });
    emitProfileSync?.(player, result.profile);
    broadcastLeaderboard();
    emitPlayers();
  });

  socket.on("tutorial:update", async payload=>{
    if(!guard("tutorial:update")) return;
    const player = players.get(socket.id);
    const gamePlayer = player?.clientMode === "game" && player.connected !== false && player.state
      ? player
      : [...players.values()]
        .filter(candidate=>player?.accountId && candidate.accountId === player.accountId
          && candidate.clientMode === "game" && candidate.connected !== false && candidate.state)
        .sort((a,b)=>Number(b.state.updatedAt || 0) - Number(a.state.updatedAt || 0))[0];
    const result = profileManager.updateProfileForPlayer({
      player,
      update:profile=>applyTutorialAction(profile, {
        kind:payload?.kind,
        currentStep:payload?.currentStep,
        revision:payload?.revision
      }, {player:gamePlayer})
    });
    if(!result?.ok){
      socket.emit("tutorial:error", {
        message:result?.reason || "Mise a jour du tutoriel impossible.",
        code:result?.code || "",
        tutorial:result?.profile?.tutorial || profileManager.getProfileSnapshotForPlayer?.(player)?.tutorial
      });
      if(result?.changed && result?.profile) emitProfileSync?.(player, result.profile);
      return;
    }
    if(!await confirmProfileSave(socket, result, {eventName:"tutorial:error"})) return;
    socket.emit("tutorial:updated", {
      tutorial:result.profile?.tutorial,
      rewardItemId:result.rewardItemId || null,
      recovered:result.recovered === true,
      at:Date.now()
    });
    emitProfileSync?.(player, result.profile);
  });

  socket.on("profile:debug-reset-firm", async ()=>{
    if(!guard("profile:debug-reset-firm")) return;
    const player = players.get(socket.id);
    if(!isLocalDebugSocket()){
      socket.emit("profile:setup-error", {message:"Commande debug firme refusee hors serveur local."});
      return;
    }
    if(!player?.accountId){
      socket.emit("profile:setup-error", {message:"Connecte un compte avant de reinitialiser la firme."});
      return;
    }
    const result = profileManager.updateProfileForPlayer({
      player,
      update:profile=>{
        profile.player = {...profile.player, firmSelected:false};
        profile.worldSession = null;
        profile.shipWorldSessions = {};
        return {ok:true};
      }
    });
    if(!result.ok){
      socket.emit("profile:setup-error", {message:result.reason || "Reinitialisation firme impossible."});
      return;
    }
    if(!await confirmProfileSave(socket, result, {eventName:"profile:setup-error"})) return;
    player.state = null;
    player.firmId = result.profile?.player?.firmId || player.account?.firmId || "astra";
    socket.emit("profile:debug-firm-reset", {firmId:result.profile?.player?.firmId, at:Date.now()});
    emitProfileSync?.(player, result.profile);
    broadcastLeaderboard();
  });

  socket.on("player:state", payload=>{
    if(!guard("player:state")) return;
    const player = players.get(socket.id);
    if(!player) return;
    player.connected = true;
    player.disconnecting = false;
    player.removeAt = 0;
    if(player.shipSwitchLockUntil && Date.now() < Number(player.shipSwitchLockUntil || 0)){
      return;
    }
    player.shipSwitchLockUntil = 0;
    const now = Date.now();
    const previousState = player.state || null;
    const source = normalizeStateSource(player, payload, previousState, now);
    if(!source) return;
    player.clientPageHidden = payload?.pageHidden === true;
    const requestedMapChange = previousState
      && String(payload?.mapId ?? previousState.mapId) !== String(previousState.mapId ?? player.mapId);
    // Portal stops and arrivals still need normal validation when the tab is hidden.
    const backgroundSnapshot = payload?.pageHidden === true && previousState
      && !requestedMapChange && payload?.portalTransfer !== true;
    const validationPayload = backgroundSnapshot
      ? {
          ...payload,
          x:previousState.x,
          y:previousState.y,
          hp:previousState.hp,
          maxHp:previousState.maxHp,
          shield:previousState.shield,
          maxShield:previousState.maxShield,
          mapId:previousState.mapId,
          moveTarget:previousState.moveTarget || payload?.moveTarget || null,
          attackTargetId:previousState.attackTargetId || payload?.attackTargetId || "",
          attackAmmoId:previousState.attackAmmoId || payload?.attackAmmoId || "",
          attackWeaponClass:previousState.attackWeaponClass || payload?.attackWeaponClass || "",
          repairBotActive:payload?.repairBotActive ?? previousState.repairBotActive ?? false
        }
      : payload;
    if(backgroundSnapshot){
      if(!Number.isFinite(Number(player.lastClientStateAt))) player.lastClientStateAt = Number(previousState.updatedAt || now);
    }else{
      player.lastClientStateAt = now;
    }
    const profile = profileManager.getProfileSnapshotForPlayer?.(player)
      || profileManager.getProfileForPlayer(player);
    const validation = validatePlayerState({
      player,
      payload:validationPayload,
      profile,
      groups,
      firmBoosters:firmWarManager?.getActiveBoosters?.(
        profile?.player?.firmId || player.account?.firmId || "astra",
        profile,
        player,
        profileManager.profileKeyForPlayer?.(player) || ""
      ) || {},
      now
    });
    const motionDiscontinuity = !previousState
      || String(previousState.mapId ?? "") !== String(validation.state.mapId ?? "");
    Object.assign(validation.state, {
      sourceSeq:source.sourceSeq,
      sourceAt:source.sourceAt,
      streamSeq:source.streamSeq,
      serverAt:source.serverAt,
      motionDiscontinuity
    });
    player.lastClientStateSourceSeq = source.sourceSeq;
    if(source.rawSourceAt !== null) player.lastClientStateRawAt = source.rawSourceAt;
    player.lastClientStateNormalizedAt = source.sourceAt;
    player.stateStreamSeq = source.streamSeq;
    player.lastStateStreamAt = now;
    const reliableStateBroadcast = requiresReliableStateBroadcast(player, previousState, validation.state, payload, now);
    player.state = validation.state;
    const moved = !previousState
      || Math.hypot(
        Number(validation.state.x || 0) - Number(previousState.x || 0),
        Number(validation.state.y || 0) - Number(previousState.y || 0)
      ) >= 1
      || Math.hypot(Number(validation.state.vx || 0), Number(validation.state.vy || 0)) > 1;
    if(!backgroundSnapshot && moved) presence.markActivity?.(player, "deplacement", now);
    if(player.pendingPortgunTeleport && hasPortgunTeleportMoved(player.pendingPortgunTeleport, player.state)){
      cancelPendingPortgun(player, "moved", "Teleportation annulee : ton vaisseau a bouge.");
    }
    const nextMapId = validation.state.mapId;
    const mapChanged = previousState
      ? String(validation.state.mapId ?? "") !== String(previousState.mapId ?? "")
      : String(validation.state.mapId ?? "") !== String(player.mapId ?? "");
    if(validation.corrected && shouldEmitPlayerStateCorrection({player, validation, now})){
      logger?.warn?.("Player state corrected", {
        playerId:player.id,
        accountId:player.accountId || null,
        reason:validation.reason,
        details:validation.correctionDetails || []
      });
      socket.emit("player:state-correction", {
        ...validation.state,
        source:"state-correction",
        vitalsOnly:isVitalOnlyStateCorrection(validation)
      });
    }
    profileManager.saveWorldSession({player, state:player.state, force:mapChanged});
    presence.syncMovementLogoutState(player);
    setPlayerMap(socket, nextMapId);
    const visibilityRooms = [...new Set([player.mapRoom].filter(Boolean))];
    if(visibilityRooms.length){
      const target = socket.to(visibilityRooms);
      const emitter = reliableStateBroadcast ? target : target?.volatile || target;
      emitter.emit("player:state", publicPlayer(player, {profile}));
      if(reliableStateBroadcast) player.lastReliableStateBroadcastAt = now;
    }
  });

  socket.on("player:activity", payload=>{
    if(!guard("player:activity")) return;
    const player = players.get(socket.id);
    if(!player || player.clientMode !== "game") return;
    presence.markActivity?.(player, String(payload?.kind || "action"), Date.now());
  });

  socket.on("portgun:teleport", payload=>{
    if(!guard("portgun:teleport")) return;
    const player = players.get(socket.id);
    if(!player) return;
    const now = Date.now();
    const profile = profileManager.getProfileForPlayer(player);
    const validation = validatePortgunTeleport({
      player,
      profile,
      targetMapId:payload?.mapId,
      now
    });
    if(!validation.ok){
      emitPortgunError(validation.reason || "Teleportation impossible.", {
        requirement:validation.requirement,
        level:validation.level
      });
      return;
    }
    const teleportId = `portgun_${now}_${Math.random().toString(36).slice(2, 8)}`;
    player.pendingPortgunTeleport = {
      id:teleportId,
      targetMapId:String(validation.map.id),
      startMapId:String(player.state.mapId || player.mapId || "0"),
      startX:Number(player.state.x || 0),
      startY:Number(player.state.y || 0),
      startedAt:now,
      completeAt:now + validation.durationMs
    };
    socket.emit("portgun:started", {
      id:teleportId,
      targetMapId:String(validation.map.id),
      targetMapName:validation.map.displayName || validation.map.name,
      durationMs:validation.durationMs,
      completeAt:player.pendingPortgunTeleport.completeAt,
      at:now
    });
    setTimeout(()=>{
      completePendingPortgun(socket.id, teleportId).catch(error=>{
        logger?.warn?.("Portgun completion failed", {playerId:socket.id, error:error?.message || String(error)});
      });
    }, validation.durationMs);
  });

  socket.on("player:laser", payload=>{
    if(!guard("player:laser")) return;
    const player = players.get(socket.id);
    if(!player || player.clientMode !== "game" || !player.state) return;
    presence.markCombat(player, "tir joueur");
    const kind = ["laser", "rocket", "missile"].includes(payload?.kind) ? payload.kind : "laser";
    const starts = (Array.isArray(payload?.starts) ? payload.starts : [{
      x:payload?.fromX,
      y:payload?.fromY,
      curveSide:payload?.curveSide,
      curveStrength:payload?.curveStrength
    }]).slice(0, 12).map(start=>({
      x:Number(start?.x || 0),
      y:Number(start?.y || 0),
      curveSide:Math.max(-1, Math.min(1, Number(start?.curveSide || 0))),
      curveStrength:Math.max(0, Math.min(160, Number(start?.curveStrength || 0)))
    }));
    const toX = finiteNumber(payload?.toX);
    const toY = finiteNumber(payload?.toY);
    if(toX === null || toY === null || !canEmitWeaponVisual(player, payload, starts)) return;
    socket.to(player.mapRoom).emit("player:laser", {
      sourceId:socket.id,
      kind,
      ammoId:String(payload?.ammoId || "ammo_x1").slice(0, 40),
      targetId:String(payload?.targetId || "").slice(0, 100),
      starts,
      fromX:Number(starts[0]?.x || payload?.fromX || 0),
      fromY:Number(starts[0]?.y || payload?.fromY || 0),
      toX,
      toY,
      blueLaser:payload?.blueLaser === true,
      travelTime:Math.max(.1, Math.min(2, Number(payload?.travelTime || .2))),
      mapId:String(player.mapId ?? player.state.mapId ?? "0"),
      color:String(payload?.color || "rgba(56,189,248,.9)").slice(0, 48),
      life:Math.max(0.05, Math.min(0.35, Number(payload?.life || 0.16))),
      createdAt:Date.now()
    });
  });

  socket.on("session:logout-request", ()=>{
    if(!guard("session:logout-request")) return;
    presence.startLogout(socket);
  });

  socket.on("player:respawn", payload=>{
    if(!guard("player:respawn")) return;
    respawnPlayer?.(socket, payload?.choice);
  });
}

export const PRESTIGE_PORTAL_META = Object.freeze({
  id:"eternal",
  name:"Le Cœur de l’Éternel",
  shortName:"Cœur de l’Éternel",
  slug:"coeur_eternel"
});

export const portals = [
  {
    id:"blue",
    name:"Le Seuil d’Azuron",
    shortName:"Seuil d’Azuron",
    img:"assets/portals/seuil_azuron.png?v=20260726-kharon1",
    pieceImg:"assets/portal_pieces/fragment_azuron.png?v=20260726-kharon1",
    pieceLabel:"Fragments d’Azuron",
    pieceName:"Fragment d’Azuron",
    pieceUnit:"fragments",
    level:"NIV. 10+",
    requirement:{level:10},
    piecesRequired:15,
    dropZones:["Maps 1 à 4"],
    dropChance:0.0033,
    casterDropChance:0.04,
    reward:"10 000 munitions x4 · 10 000 NOVA · Laser MK-IV garanti au premier nettoyage, puis 25%",
    desc:"Boucliers, sentinelles et initiation · 20 vagues par groupes de 4",
    contentStatus:"ready",
    contentLabel:"Contenu disponible",
    waves:20,
    waveBatchSize:4,
    waveIntervalMs:10_000,
    open:false
  },
  {
    id:"violet",
    name:"La Faille de Vesper",
    shortName:"Faille de Vesper",
    img:"assets/portals/faille_vesper.png?v=20260726-kharon1",
    pieceImg:"assets/portal_pieces/fragment_vesper.png?v=20260726-kharon1",
    pieceLabel:"Fragments de Vesper",
    pieceName:"Fragment de Vesper",
    pieceUnit:"fragments",
    level:"NIV. 15+",
    requirement:{level:15},
    piecesRequired:20,
    dropZones:["Maps 1 à 4"],
    dropChance:0.0033,
    casterDropChance:0.04,
    reward:"20 000 munitions x4 · 20 000 NOVA · Noyau Overdrive Drone garanti au premier nettoyage, puis 50%",
    desc:"Mission de sauvetage · neutralisez les tourelles et les gardiens, libérez les 4 drones prisonniers, puis éliminez le Drone Géant.",
    contentStatus:"ready",
    contentLabel:"Sauvetage tactique · 4 cages · 3 vies",
    open:false
  },
  {
    id:"red",
    name:"La Forge de Kharon",
    shortName:"Forge de Kharon",
    img:"assets/portals/forge_kharon.png?v=20260726-kharon1",
    pieceImg:"assets/portal_pieces/fragment_kharon.png?v=20260726-kharon1",
    pieceLabel:"Fragments de Kharon",
    pieceName:"Fragment de Kharon",
    pieceUnit:"fragments",
    level:"NIV. 20+",
    requirement:{level:20},
    piecesRequired:35,
    dropZones:["Maps 1 à 5"],
    dropChance:0.0033,
    casterDropChance:0.04,
    reward:"30 000 munitions x4 · 30 000 NOVA · Tirage exclusif : Laser MK-IV 33% · skin drone 33% · rien 34% · Déverrouille les vaisseaux élite et à compétence",
    desc:"30 vagues niveau 20 · assauts par groupes · Vesperion vague 10 · Nyxaris vague 20 · Asterion vague 30.",
    contentStatus:"ready",
    contentLabel:"30 vagues · 3 boss · 3 vies",
    waves:30,
    waveIntervalMs:10_000,
    open:false
  },
  {
    id:"ionis",
    name:"La Tempête d’Ionis",
    shortName:"Tempête d’Ionis",
    img:"assets/portals/tempete_ionis.png?v=20260726-kharon1",
    pieceImg:"assets/portal_pieces/fragment_ionis.png?v=20260726-kharon1",
    pieceLabel:"Fragments d’Ionis",
    pieceName:"Fragment d’Ionis",
    pieceUnit:"fragments",
    level:"NIV. 25+",
    requirement:{level:25},
    piecesRequired:50,
    dropZones:["Maps 2 à 5","CORE"],
    dropChance:0.0033,
    casterDropChance:0.04,
    reward:"40 000 munitions x4 · 40 000 NOVA · Déverrouille les futures améliorations d’équipement",
    desc:"40 vagues niveau 25 · 10 groupes de 4 · assaut d’élite final à la vague 40.",
    contentStatus:"ready",
    contentLabel:"40 vagues · 10 groupes · 3 vies",
    waves:40,
    waveBatchSize:4,
    waveIntervalMs:10_000,
    open:false
  },
  {
    id:"emerald",
    name:"La Ruche d’Éclanite",
    shortName:"Ruche d’Éclanite",
    img:"assets/portals/ruche_eclanite.png?v=20260726-kharon1",
    pieceImg:"assets/portal_pieces/fragment_eclanite.png?v=20260726-kharon1",
    pieceLabel:"Fragments d’Éclanite",
    pieceName:"Fragment d’Éclanite",
    pieceUnit:"fragments",
    level:"NIV. 30+",
    requirement:{level:30},
    piecesRequired:60,
    dropZones:["Maps 2 à 5","CORE"],
    dropChance:0.0033,
    casterDropChance:0.04,
    reward:"5 000 munitions x6 · 50 000 NOVA · Débloque les recettes, dont les lasers bleu, vert et rouge",
    desc:"3 compartiments · gardiens, noyau ×5 puis boss à PV restants · 3 minutes par zone.",
    contentStatus:"ready",
    contentLabel:"3 zones · noyaux ×5 · 3 boss · 3 vies",
    open:false
  },
  {
    id:"void",
    name:"L’Abîme de Nox",
    shortName:"Abîme de Nox",
    img:"assets/portals/abime_nox.png?v=20260726-kharon1",
    pieceImg:"assets/portal_pieces/fragment_nox.png?v=20260726-kharon1",
    pieceLabel:"Fragments de Nox",
    pieceName:"Fragment de Nox",
    pieceUnit:"fragments",
    level:"NIV. 35+",
    requirement:{level:35},
    piecesRequired:75,
    dropZones:["Maps 3 à 5","CORE","Zones niv. 35 à 50"],
    dropChance:0.0033,
    casterDropChance:0.04,
    reward:"10 000 munitions x6 · 50 000 NOVA · Tirage : laser bleu 15% · laser rouge 15% · laser vert 15% · rien 55%",
    desc:"Défense de station · 30 vagues par groupes de 5 · protège le bouclier, les défenses autonomes et le noyau jusqu’au boss final.",
    contentStatus:"ready",
    contentLabel:"30 vagues · 6 assauts · défense de station · 3 vies",
    waves:30,
    waveBatchSize:5,
    open:false
  },
  {
    id:"prismatic",
    name:"Le Nexus Prismatique",
    shortName:"Nexus Prismatique",
    img:"assets/portals/nexus_prismatique.png?v=20260726-kharon1",
    pieceImg:"assets/portal_pieces/fragment_nexus_prismatique.png?v=20260726-kharon1",
    pieceLabel:"Fragments prismatiques",
    pieceName:"Fragment prismatique",
    pieceUnit:"fragments",
    level:"NIV. 40+",
    requirement:{level:40},
    piecesRequired:80,
    dropZones:["Maps 4 à 5","CORE","Zones niv. 35 à 50"],
    dropChance:0.0033,
    casterDropChance:0.04,
    reward:"50 000 munitions x4 · 50 000 NOVA · Tirage : drone ancestral 33% · Laser MK-IV 33% · rien 34%",
    desc:"Détruisez les planètes de feu, d’eau et rouge cristalline sous la garde des drones ancestraux, traversez le trou noir central, puis affrontez la triade prismatique.",
    contentStatus:"ready",
    contentLabel:"3 planètes · trou noir · 3 boss prismatiques · 3 vies",
    open:false
  },
  {
    id:"ancient",
    name:"Le Sanctuaire des Précurseurs",
    shortName:"Sanctuaire des Précurseurs",
    img:"assets/portals/sanctuaire_precurseurs.png?v=20260726-kharon1",
    pieceImg:"assets/portal_pieces/fragment_sanctuaire_precurseurs.png?v=20260726-kharon1",
    pieceLabel:"Fragments des Précurseurs",
    pieceName:"Fragment des Précurseurs",
    pieceUnit:"fragments",
    level:"NIV. 45+",
    requirement:{level:45},
    piecesRequired:90,
    dropZones:["Map 5","CORE","Zones niv. 35 à 50"],
    dropChance:0.0033,
    casterDropChance:0.04,
    reward:"15 000 munitions x6 · 75 000 NOVA · Tirage : skin ancestral inférieur (+20% attaque ou bouclier selon le module) 50% · laser coloré aléatoire 50%",
    desc:"Échappez-vous de l’enfer en explorant cinq salles secrètes, libérez deux vaisseaux-anges, récupérez le talisman gardé par un demi-boss, ouvrez la faille vers le paradis puis terrassez le Roi des démons avec l’aide des anges.",
    contentStatus:"ready",
    contentLabel:"5 salles secrètes · 2 anges · talisman · faille · Roi des démons · 3 vies",
    open:false
  },
  {
    id:PRESTIGE_PORTAL_META.id,
    name:PRESTIGE_PORTAL_META.name,
    shortName:PRESTIGE_PORTAL_META.shortName,
    img:`assets/portals/${PRESTIGE_PORTAL_META.slug}.png?v=20260726-kharon1`,
    pieceImg:`assets/portal_pieces/fragment_${PRESTIGE_PORTAL_META.slug}.png?v=20260726-kharon1`,
    pieceLabel:"Fragments de l’Éternel",
    pieceName:"Fragment de l’Éternel",
    pieceUnit:"fragments",
    level:"NIV. 50+",
    requirement:{level:50},
    piecesRequired:100,
    dropZones:["À définir"],
    dropChance:0.0033,
    casterDropChance:0.04,
    reward:"25 000 munitions x6 · 100 000 NOVA · Ornement animé · Titre « Système stellaire colonisé » (+5% tous dégâts) · Prestige après les 8 portails précédents",
    desc:"Contenu à définir.",
    contentStatus:"to_define",
    contentLabel:"Contenu à définir",
    prerequisitePortalIds:["blue","violet","red","ionis","emerald","void","prismatic","ancient"],
    open:false
  }
];

export const skills = [
  {
    id:"damage",
    name:"Branche Dégâts",
    short:"Dégâts",
    icon:"⚔",
    theme:"offense",
    desc:"Optimise les systèmes offensifs du vaisseau. Chaque compétence possède plusieurs rangs avant d'ouvrir la suivante.",
    maxLevel:5,
    levels:[
      {name:"Calibrage laser", ranks:[
        {skillPoints:1, priceType:"credits", price:10000, stats:{weaponDamageMultiplier:1.02}, label:"+2 % dégâts laser"},
        {skillPoints:1, priceType:"credits", price:500000, stats:{weaponDamageMultiplier:1.04}, label:"+4 % dégâts laser"},
        {skillPoints:1, costs:{premium:1000, materials:{alliage_cuivre_zinc:500, plaque_nickel_titane:500}}, stats:{weaponDamageMultiplier:1.06}, label:"+6 % dégâts laser"}
      ]},
      {name:"Surcharge stable", ranks:[
        {skillPoints:1, costs:{credits:1000000, materials:{alliage_cuivre_zinc:1000, plaque_nickel_titane:1000}}, stats:{rocketDamageMultiplier:1.02}, label:"+2 % dégâts roquette"},
        {skillPoints:1, costs:{credits:2000000, materials:{alliage_cuivre_zinc:2500, plaque_nickel_titane:2500}}, stats:{rocketDamageMultiplier:1.04}, label:"+4 % dégâts roquette"},
        {skillPoints:1, costs:{premium:5000, materials:{catalyseur_quantique:5000}}, stats:{rocketDamageMultiplier:1.06}, label:"+6 % dégâts roquette"}
      ]},
      {name:"Noyau offensif", ranks:[
        {skillPoints:1, costs:{credits:5000000, materials:{conducteur_renforce:2500, blindage_composite:2500}}, stats:{missileDamageMultiplier:1.02}, label:"+2 % dégâts missile"},
        {skillPoints:1, costs:{credits:10000000, materials:{conducteur_renforce:5000, blindage_composite:5000}}, stats:{missileDamageMultiplier:1.04}, label:"+4 % dégâts missile"},
        {skillPoints:1, costs:{premium:10000, materials:{conducteur_renforce:10000, blindage_composite:10000}}, stats:{missileDamageMultiplier:1.06}, label:"+6 % dégâts missile"}
      ]},
      {name:"Cadence roquettes", ranks:[
        {skillPoints:1, costs:{credits:25000000, materials:{noyau_astra:100}}, stats:{rocketCooldownMultiplier:0.95}, label:"-5 % délai roquette"},
        {skillPoints:1, costs:{credits:50000000, materials:{noyau_astra:200}}, stats:{rocketCooldownMultiplier:0.90}, label:"-10 % délai roquette"},
        {skillPoints:1, costs:{premium:25000, materials:{noyau_astra:500}}, stats:{rocketCooldownMultiplier:0.85}, label:"-15 % délai roquette"}
      ]},
      {name:"Calibrage laser II", ranks:[
        {skillPoints:1, costs:{credits:250000000, materials:{noyau_astra:1000}}, stats:{weaponDamageMultiplier:1.0188679245}, label:"+8 % dégâts laser"},
        {skillPoints:1, costs:{credits:500000000, materials:{noyau_astra:2000}}, stats:{weaponDamageMultiplier:1.0377358491}, label:"+10 % dégâts laser"},
        {skillPoints:1, costs:{premium:70000, materials:{noyau_astra:5000}}, stats:{weaponDamageMultiplier:1.0849056604, blueLaserBeams:1}, label:"+15 % dégâts laser · lasers bleus"}
      ]}
    ]
  },
  {
    id:"shield",
    name:"Branche Bouclier",
    short:"Bouclier",
    icon:"⬢",
    theme:"defense",
    desc:"Renforce la survie du vaisseau. Chaque compétence possède plusieurs rangs avant d'ouvrir la suivante.",
    maxLevel:5,
    levels:[
      {name:"Trame bouclier", ranks:[
        {skillPoints:1, priceType:"credits", price:10000, stats:{shieldMultiplier:1.02}, label:"+2 % bouclier"},
        {skillPoints:1, priceType:"credits", price:500000, stats:{shieldMultiplier:1.04}, label:"+4 % bouclier"},
        {skillPoints:1, costs:{premium:1000, materials:{alliage_cuivre_zinc:500, plaque_nickel_titane:500}}, stats:{shieldMultiplier:1.06}, label:"+6 % bouclier"}
      ]},
      {name:"Condensateurs", ranks:[
        {skillPoints:1, costs:{credits:1000000, materials:{alliage_cuivre_zinc:1000, plaque_nickel_titane:1000}}, stats:{evasionChance:0.02}, label:"+2 % esquive"},
        {skillPoints:1, costs:{credits:2000000, materials:{alliage_cuivre_zinc:2500, plaque_nickel_titane:2500}}, stats:{evasionChance:0.04}, label:"+4 % esquive"},
        {skillPoints:1, costs:{premium:5000, materials:{catalyseur_quantique:5000}}, stats:{evasionChance:0.06}, label:"+6 % esquive"}
      ]},
      {name:"Blindage actif", ranks:[
        {skillPoints:1, costs:{credits:5000000, materials:{conducteur_renforce:2500, blindage_composite:2500}}, stats:{shieldAbsorbBonus:0.02}, label:"+2 % absorption bouclier"},
        {skillPoints:1, costs:{credits:10000000, materials:{conducteur_renforce:5000, blindage_composite:5000}}, stats:{shieldAbsorbBonus:0.04}, label:"+4 % absorption bouclier"},
        {skillPoints:1, costs:{premium:10000, materials:{conducteur_renforce:10000, blindage_composite:10000}}, stats:{shieldAbsorbBonus:0.06}, label:"+6 % absorption bouclier"}
      ]},
      {name:"Régénération", ranks:[
        {skillPoints:1, costs:{credits:25000000, materials:{noyau_astra:100}}, stats:{regenMultiplier:1.02}, label:"+2 % régénération bouclier"},
        {skillPoints:1, costs:{credits:50000000, materials:{noyau_astra:200}}, stats:{regenMultiplier:1.04}, label:"+4 % régénération bouclier"},
        {skillPoints:1, costs:{premium:25000, materials:{noyau_astra:500}}, stats:{regenMultiplier:1.06}, label:"+6 % régénération bouclier"}
      ]},
      {name:"Renfort de coque", ranks:[
        {skillPoints:1, costs:{credits:250000000, materials:{noyau_astra:1000}}, stats:{hullMultiplier:1.02}, label:"+2 % vie du vaisseau"},
        {skillPoints:1, costs:{credits:500000000, materials:{noyau_astra:2000}}, stats:{hullMultiplier:1.04}, label:"+4 % vie du vaisseau"},
        {skillPoints:1, costs:{premium:70000, materials:{noyau_astra:5000}}, stats:{hullMultiplier:1.10}, label:"+10 % vie du vaisseau"}
      ]}
    ]
  },
  {
    id:"utility",
    name:"Branche Utilitaire",
    short:"Utilitaire",
    icon:"✦",
    theme:"utility",
    desc:"Développe les fonctions de soutien : mobilité, soute et logistique de combat.",
    maxLevel:5,
    levels:[
      {name:"Propulseurs", ranks:[
        {skillPoints:1, priceType:"credits", price:10000, stats:{speedMultiplier:1.02}, label:"+2 % vitesse"},
        {skillPoints:1, priceType:"credits", price:500000, stats:{speedMultiplier:1.04}, label:"+4 % vitesse"},
        {skillPoints:1, costs:{premium:1000, materials:{alliage_cuivre_zinc:500, plaque_nickel_titane:500}}, stats:{speedMultiplier:1.06}, label:"+6 % vitesse"}
      ]},
      {name:"Soute optimisée", ranks:[
        {skillPoints:1, costs:{credits:1000000, materials:{alliage_cuivre_zinc:1000, plaque_nickel_titane:1000}}, stats:{lootMultiplier:1.02}, label:"+2 % crédits"},
        {skillPoints:1, costs:{credits:2000000, materials:{alliage_cuivre_zinc:2500, plaque_nickel_titane:2500}}, stats:{lootMultiplier:1.04}, label:"+4 % crédits"},
        {skillPoints:1, costs:{premium:5000, materials:{catalyseur_quantique:5000}}, stats:{lootMultiplier:1.06}, label:"+6 % crédits"}
      ]},
      {name:"Drone soutien", ranks:[
        {skillPoints:1, costs:{credits:5000000, materials:{conducteur_renforce:2500, blindage_composite:2500}}, stats:{cargoMultiplier:1.04}, label:"+4 % taille de soute"},
        {skillPoints:1, costs:{credits:10000000, materials:{conducteur_renforce:5000, blindage_composite:5000}}, stats:{cargoMultiplier:1.08}, label:"+8 % taille de soute"},
        {skillPoints:1, costs:{premium:10000, materials:{conducteur_renforce:10000, blindage_composite:10000}}, stats:{cargoMultiplier:1.12}, label:"+12 % taille de soute"}
      ]},
      {name:"Drone réparation", ranks:[
        {skillPoints:1, costs:{credits:25000000, materials:{noyau_astra:100}}, stats:{repairBotHealMultiplier:1.05}, label:"+5 % soin drone"},
        {skillPoints:1, costs:{credits:50000000, materials:{noyau_astra:200}}, stats:{repairBotHealMultiplier:1.10}, label:"+10 % soin drone"},
        {skillPoints:1, costs:{premium:25000, materials:{noyau_astra:500}}, stats:{repairBotHealMultiplier:1.15}, label:"+15 % soin drone"}
      ]},
      {name:"Protocoles NOVA", ranks:[
        {skillPoints:1, costs:{credits:250000000, materials:{noyau_astra:1000}}, stats:{novaMultiplier:1.02}, label:"+2 % NOVA"},
        {skillPoints:1, costs:{credits:500000000, materials:{noyau_astra:2000}}, stats:{novaMultiplier:1.04}, label:"+4 % NOVA"},
        {skillPoints:1, costs:{premium:70000, materials:{noyau_astra:5000}}, stats:{novaMultiplier:1.10}, label:"+10 % NOVA"}
      ]}
    ]
  }
];

import { COMMON_CRAFT_RESOURCES, ELITE_CRAFT_RESOURCES, MYTHIC_CRAFT_RESOURCES, RARE_CRAFT_RESOURCES, VERY_RARE_CRAFT_RESOURCES } from "./resources.js";

export const rawMaterialCatalog = [
  {id:"cuivre_orbital", name:"Cuivre", short:"CUI", kind:"raw", tier:1, img:"assets/materials/cuivre_orbital.svg", desc:"Métal conducteur extrait des débris orbitaux.", maxLevel:20},
  {id:"zinc_spatial", name:"Zinc", short:"ZNC", kind:"raw", tier:1, img:"assets/materials/zinc_spatial.svg", desc:"Minerai léger utilisé pour stabiliser les alliages.", maxLevel:20},
  {id:"nickel_brut", name:"Nickel", short:"NIC", kind:"raw", tier:1, img:"assets/materials/nickel_brut.svg", desc:"Minerai dense récupéré sur les coques ennemies.", maxLevel:20},
  {id:"titane_fissure", name:"Titane", short:"TIT", kind:"raw", tier:1, img:"assets/materials/titane_fissure.svg", desc:"Titane instable destiné aux plaques de protection.", maxLevel:20},
  {id:"silice_conductrice", name:"Silice", short:"SIL", kind:"raw", tier:1, img:"assets/materials/silice_conductrice.svg", desc:"Cristal industriel employé dans les circuits de raffinerie.", maxLevel:20},
  ...COMMON_CRAFT_RESOURCES,
  ...RARE_CRAFT_RESOURCES,
  ...VERY_RARE_CRAFT_RESOURCES,
  ...ELITE_CRAFT_RESOURCES,
  ...MYTHIC_CRAFT_RESOURCES,
  {id:"alliage_cuivre_zinc", name:"Alliage", short:"ACZ", kind:"refined", tier:2, img:"assets/materials/alliage_cuivre_zinc.svg", desc:"Alliage de base pour les systèmes conducteurs.", maxLevel:20},
  {id:"plaque_nickel_titane", name:"Plaque", short:"PNT", kind:"refined", tier:2, img:"assets/materials/plaque_nickel_titane.svg", desc:"Plaque renforcée pour les structures et blindages.", maxLevel:20},
  {id:"conducteur_renforce", name:"Conducteur", short:"CDR", kind:"advanced", tier:3, img:"assets/materials/conducteur_renforce.svg", desc:"Composant avancé pour les armes et circuits de puissance.", maxLevel:20},
  {id:"blindage_composite", name:"Blindage", short:"BLC", kind:"advanced", tier:3, img:"assets/materials/blindage_composite.svg", desc:"Composant avancé pour renforcer la coque et les modules.", maxLevel:20},
  {id:"catalyseur_quantique", name:"Catalyseur", short:"CAT", kind:"special", tier:4, img:"assets/materials/catalyseur_quantique.svg", desc:"Catalyseur de transition fabriqué avec minerais lourds et zinc stabilisé.", maxLevel:20},
  {id:"noyau_astra", name:"Noyau", short:"AST", kind:"final", tier:5, img:"assets/materials/noyau_astra.svg", desc:"Matériau final destiné aux grosses améliorations de vaisseau.", maxLevel:20}
];

export const refineryMaterialCatalog = rawMaterialCatalog.filter(material=>!material.rarity);
export const craftResourceCatalog = rawMaterialCatalog.filter(material=>Boolean(material.rarity));

export const refineryRecipes = [
  {id:"refine_cuivre_zinc", name:"Fusion cuivre-zinc", outputId:"alliage_cuivre_zinc", outputAmount:1, durationMs:60_000, costs:{cuivre_orbital:10, zinc_spatial:5}, desc:"Fusionne cuivre orbital et zinc spatial en alliage conducteur."},
  {id:"refine_nickel_titane", name:"Forge plaque", outputId:"plaque_nickel_titane", outputAmount:1, durationMs:75_000, costs:{titane_fissure:5, silice_conductrice:10}, desc:"Compresse titane et silice en plaque renforcée."},
  {id:"refine_catalyseur", name:"Synthese catalyseur", outputId:"catalyseur_quantique", outputAmount:1, durationMs:90_000, costs:{zinc_spatial:5, nickel_brut:10, titane_fissure:5}, desc:"Stabilise zinc, nickel et titane en catalyseur."},
  {id:"refine_conducteur", name:"Assemblage conducteur renforcé", outputId:"conducteur_renforce", outputAmount:1, durationMs:120_000, costs:{alliage_cuivre_zinc:10, catalyseur_quantique:5}, desc:"Combine alliage et catalyseur en composant conducteur avancé."},
  {id:"refine_blindage", name:"Assemblage blindage composite", outputId:"blindage_composite", outputAmount:1, durationMs:120_000, costs:{plaque_nickel_titane:10, catalyseur_quantique:5}, desc:"Renforce les plaques avec un catalyseur quantique."},
  {id:"refine_noyau_astra", name:"Stabilisation Noyau d'Astra", outputId:"noyau_astra", outputAmount:1, durationMs:240_000, costs:{catalyseur_quantique:10, conducteur_renforce:10, blindage_composite:10}, desc:"Stabilise les composants avancés avec un catalyseur spécial."}
];

const generatedCombatQuests = [
  ["quest_lv3_combat_drone_companion", "normal", 3, "Un drone de compagnie", "Possède au moins 1 drone de combat. Si tu en possèdes déjà un, retourne simplement au relais.", "owned_combat_drone", 1, "Hangar", 23000, 3500, {}, 200],
  ["quest_astra01_raider_easy_02", "daily", 3, "Prime de patrouille", "Détruis 12 Vorak rushers dans Helion-01.", "raider_astral", 12, "Helion-01", 26000, 1300, {nickel_brut:16, titane_fissure:8}],
  ["quest_astra03_spectral_hard_01", "weekly", 10, "Purge Helion-03", "Détruis 35 Parasites astraux dans Helion-03.", "chasseur_spectral", 35, "Helion-03", 150000, 9200, {silice_conductrice:70, catalyseur_quantique:5}],
  ["quest_astra04_spectral_hard_01", "normal", 12, "Ombres d'Helion-04", "Détruis 22 Pondeuses astrales dans Helion-04.", "pondeuse_astrale", 22, "Helion-04", 115000, 7200, {silice_conductrice:50, catalyseur_quantique:4}],
  ["quest_astra04_spectral_hard_02", "weekly", 14, "Front spectral lourd", "Détruis 45 Pondeuses astrales dans Helion-04.", "pondeuse_astrale", 45, "Helion-04", 240000, 16000, {silice_conductrice:110, catalyseur_quantique:8}],
  ["quest_astra05_boss_orb_01", "normal", 18, "Patrouille d'Éclanites", "Détruis 5 Éclanites dans Helion-05.", "eclanite", 5, "Helion-05", 90000, 6500, {cuivre_orbital:60, zinc_spatial:30, catalyseur_quantique:3}],
  ["quest_astra05_boss_raider_01", "normal", 18, "Renforts d'Éclanites", "Détruis 5 Éclanites dans Helion-05.", "eclanite", 5, "Helion-05", 110000, 7600, {nickel_brut:60, titane_fissure:30, catalyseur_quantique:3}],
  ["quest_astra05_boss_spectral_01", "normal", 19, "Front des Cristanites", "Détruis 5 Cristanites dans Helion-05.", "cristanite", 5, "Helion-05", 150000, 9800, {silice_conductrice:70, catalyseur_quantique:4}],
  ["quest_astra05_boss_nebular_01", "normal", 20, "Percée des Cristanites", "Détruis 4 Cristanites dans Helion-05.", "cristanite", 4, "Helion-05", 190000, 12000, {alliage_cuivre_zinc:8, plaque_nickel_titane:8, catalyseur_quantique:5}],
  ["quest_astra05_boss_crystal_01", "normal", 21, "Astranites", "Détruis 4 Astranites dans Helion-05.", "astranite", 4, "Helion-05", 260000, 15500, {conducteur_renforce:5, blindage_composite:5, catalyseur_quantique:6}],
  ["quest_astra05_boss_amber_01", "normal", 22, "Menace astranite", "Détruis 3 Astranites dans Helion-05.", "astranite", 3, "Helion-05", 420000, 25000, {conducteur_renforce:8, blindage_composite:8, noyau_astra:1}],
  ["quest_astra05_boss_daily_01", "daily", 18, "Prime Éclanites", "Détruis 10 Éclanites dans Helion-05.", "eclanite", 10, "Helion-05", 180000, 12000, {catalyseur_quantique:8}],
  ["quest_astra05_boss_daily_02", "daily", 20, "Prime Cristanites", "Détruis 8 Cristanites dans Helion-05.", "cristanite", 8, "Helion-05", 240000, 16000, {silice_conductrice:120, catalyseur_quantique:10}],
  ["quest_astra05_boss_weekly_01", "weekly", 20, "Purge des Éclanites", "Détruis 25 Éclanites dans Helion-05.", "eclanite", 25, "Helion-05", 500000, 36000, {conducteur_renforce:10, blindage_composite:10, noyau_astra:2}],
  ["quest_astra05_boss_weekly_02", "weekly", 22, "Siège d'Helion-05", "Détruis 12 Astranites dans Helion-05.", "astranite", 12, "Helion-05", 1200000, 70000, {conducteur_renforce:20, blindage_composite:20, noyau_astra:5}]
].map(([id, category, requiredLevel, title, desc, target, count, zone, credits, xp, materials, premium = 0])=>({
  id,
  category,
  requiredLevel,
  title,
  giver:"Relais de Commandement",
  desc,
  objective:target === "owned_combat_drone" ? {type:"owned_combat_drone", count, zone, label:"Drone de Combat"} : {type:"kill", target, count, zone},
  rewards:{credits, premium, xp, materials}
}));

const QUEST_FIRMS = [
  {id:"astra", label:"Astra", mapPrefix:"Helion", npcPrefix:"astra"},
  {id:"cyan", label:"Cygnus", mapPrefix:"Nereid", npcPrefix:"cyan"},
  {id:"jaune", label:"Solarys", mapPrefix:"Aureon", npcPrefix:"jaune"},
  {id:"verte", label:"Verdantis", mapPrefix:"Sylva", npcPrefix:"verte"}
];

const RICKY_QUEST_COORDINATES = {
  astra:{x:430, y:-330},
  cyan:{x:430, y:330},
  jaune:{x:-430, y:330},
  verte:{x:-430, y:-330}
};

function getQuestFirmDefinition(firmId){
  return QUEST_FIRMS.find(firm=>firm.id === firmId) || QUEST_FIRMS[0];
}

function getQuestFirmMapName(firmId, num){
  const firm = getQuestFirmDefinition(firmId);
  return `${firm.mapPrefix}-${String(num).padStart(2, "0")}`;
}

function deepClone(value){
  return JSON.parse(JSON.stringify(value));
}

function firmNpcId(npcId, firmId){
  if(String(npcId || "") !== "astra02_portal_mechanic") return npcId;
  const prefix = getQuestFirmDefinition(firmId).npcPrefix;
  return `${prefix}02_portal_mechanic`;
}

function firmText(value, firmId){
  if(typeof value !== "string") return value;
  const firm = getQuestFirmDefinition(firmId);
  const mapPrefixWithDe = /^[AEIOUYH]/i.test(firm.mapPrefix) ? `d'${firm.mapPrefix}` : `de ${firm.mapPrefix}`;
  return value
    .replace(/d'Helion/g, mapPrefixWithDe)
    .replace(/HELION/g, firm.mapPrefix.toUpperCase())
    .replace(/Helion/g, firm.mapPrefix);
}

function firmZone(value, firmId){
  const match = String(value || "").match(/^Helion-(\d{2})$/i);
  if(!match) return value;
  return getQuestFirmMapName(firmId, Number(match[1]));
}

function firmObjective(objective, firmId){
  if(!objective || typeof objective !== "object" || Array.isArray(objective)) return objective;
  const next = {};
  for(const [key, value] of Object.entries(objective)){
    if(key === "zone" || key === "map") next[key] = firmZone(value, firmId);
    else if(key === "zones" && Array.isArray(value)) next[key] = value.map(zone=>firmZone(zone, firmId));
    else if(key === "npcId") next[key] = firmNpcId(value, firmId);
    else if(key === "id" && typeof value === "string") next[key] = firmText(value, firmId).toLowerCase();
    else if(typeof value === "string") next[key] = firmText(value, firmId);
    else next[key] = deepClone(value);
  }
  if(objective.id === "portal_coord" && objective.type === "visit_coordinates"){
    const coordinates = RICKY_QUEST_COORDINATES[firmId] || RICKY_QUEST_COORDINATES.astra;
    next.x = coordinates.x;
    next.y = coordinates.y;
    next.label = `Coord X ${coordinates.x} Y ${coordinates.y}`;
  }
  return next;
}

function firmQuestId(id, firmId){
  if(firmId === "astra") return id;
  const base = String(id || "quest");
  if(base.startsWith("quest_astra")) return base.replace("quest_astra", `quest_${firmId}`);
  return `${base}_${firmId}`;
}

function firmQuest(quest, firmId){
  const next = deepClone(quest);
  next.id = firmQuestId(quest.id, firmId);
  next.sourceQuestId = quest.id;
  next.firmId = firmId;
  next.title = firmText(next.title, firmId);
  next.desc = firmText(next.desc, firmId);
  next.giver = firmText(next.giver, firmId);
  if(next.objective) next.objective = firmObjective(next.objective, firmId);
  if(Array.isArray(next.objectives)) next.objectives = next.objectives.map(objective=>firmObjective(objective, firmId));
  if(next.unlock?.type === "complete_quest" && next.unlock.questId){
    next.unlock.questId = firmQuestId(next.unlock.questId, firmId);
  }
  return next;
}

function buildFirmQuestCatalog(baseQuests){
  const result = [];
  for(const firm of QUEST_FIRMS){
    for(const quest of baseQuests) result.push(firmQuest(quest, firm.id));
  }
  return result;
}

const baseQuestCatalog = [
  {
    id:"quest_drone_cleanup",
    category:"normal",
    requiredLevel:1,
    title:"Un passe droit ?",
    special:true,
    red:true,
    rewardTone:"special",
    giver:"Relais de Commandement",
    desc:"Sécurise la zone et reviens me voir, je t'offrirai ton passe droit.",
    objective:{type:"kill", target:"drone_pirate", label:"Orbe sentinelle", count:3, zones:["Helion-01","Helion-02"]},
    rewards:{credits:200000, premium:5000, xp:5000, items:["laser_mk3", "launcher_rocket_mk1"], materials:{}}
  },
  {
    id:"quest_raider_patrol",
    category:"normal",
    requiredLevel:1,
    title:"Pulvérisé à la racine",
    giver:"Relais de Commandement",
    desc:"Nettoie la zone et reviens me voir quand les Vorak rushers ne seront plus une menace.",
    objective:{type:"kill", target:"raider_astral", label:"Vorak rusher", count:3, zones:["Helion-01","Helion-02"]},
    rewards:{credits:10000, premium:150, xp:500, items:["shield_omega"], materials:{zinc_spatial:1000, cuivre_orbital:1000, nickel_brut:1000, titane_fissure:1000, silice_conductrice:1000}}
  },
  {
    id:"quest_spectral_scan",
    category:"normal",
    requiredLevel:1,
    title:"Un choix rationelle",
    giver:"Relais de Commandement",
    desc:"Améliore le module de stockage dans la raffinerie. Le lancement suffit, tu n'as pas besoin d'attendre la fin.",
    objective:{type:"refinery_module_upgrade_start", module:"storage", targetLevel:2, count:1},
    rewards:{credits:10000, premium:150, xp:500, items:["reactor_ion"], materials:{}}
  },
  {
    id:"quest_lv1_comprehension_acquisition",
    category:"normal",
    requiredLevel:1,
    title:"Compréhension acquisition",
    rare:true,
    giver:"Relais de Commandement",
    desc:"Prouve que tu maitrises les bases d'Helion-01 et rejoins Helion-02 au moins une fois.",
    unlock:{type:"complete_level_quests", level:1},
    objectives:[
      {id:"orbes", type:"kill", target:"drone_pirate", label:"Orbe sentinelle", count:5, zones:["Helion-01","Helion-02"]},
      {id:"vorak", type:"kill", target:"raider_astral", label:"Vorak rusher", count:5, zones:["Helion-01","Helion-02"]},
      {id:"astra02", type:"visit_map", map:"Helion-02", label:"Atteindre Helion-02", count:1}
    ],
    rewards:{credits:75000, premium:500, xp:1500, materials:{}, shipCargoMaterialsForced:{noyau_astra:100}}
  },
  {
    id:"quest_daily_cleanup",
    category:"daily",
    requiredLevel:4,
    title:"Prime journaliere",
    giver:"Relais de Commandement",
    desc:"Elimine 8 ennemis dans Helion-01 pour maintenir la route commerciale ouverte.",
    objective:{type:"kill", target:"drone_pirate", count:8, zone:"Helion-01"},
    rewards:{credits:18000, xp:900, materials:{cuivre_orbital:14, zinc_spatial:4}}
  },
  {
    id:"quest_lv4_place_au_combat",
    category:"normal",
    requiredLevel:4,
    title:"Place au combat",
    giver:"Relais de Commandement",
    desc:"Détruis 15 Orbes sentinelles dans les zones Helion.",
    objective:{type:"kill", target:"drone_pirate", label:"Orbe sentinelle", count:15, zones:["Helion-01","Helion-02"]},
    rewards:{credits:75000, premium:250, xp:6500, materials:{}}
  },
  {
    id:"quest_lv3_prepare_future",
    category:"normal",
    requiredLevel:3,
    title:"Prévoir pour l'avenir",
    giver:"Relais de Commandement",
    desc:"Lance l'amélioration niveau 2 du cuivre, du nickel et de la silice dans la raffinerie.",
    objectives:[
      {id:"cuivre_lv2", type:"refinery_material_upgrade_start", material:"cuivre_orbital", label:"Cuivre niveau 2", targetLevel:2, count:1},
      {id:"nickel_lv2", type:"refinery_material_upgrade_start", material:"nickel_brut", label:"Nickel niveau 2", targetLevel:2, count:1},
      {id:"silice_lv2", type:"refinery_material_upgrade_start", material:"silice_conductrice", label:"Silice niveau 2", targetLevel:2, count:1}
    ],
    rewards:{credits:23000, premium:200, xp:3500, materials:{}}
  },
  {
    id:"quest_lv3_new_range",
    category:"normal",
    requiredLevel:3,
    title:"Nouvelle Gamme",
    giver:"Relais de Commandement",
    desc:"Achète un Velox. Si le Velox est déjà dans ton hangar, retourne simplement au relais.",
    objective:{type:"owned_ship", shipId:"velox", label:"Velox possédé", count:1, zone:"Hangar"},
    rewards:{credits:23000, premium:200, xp:3500, materials:{}}
  },
  {
    id:"quest_lv3_one_step_after_another",
    category:"normal",
    requiredLevel:3,
    title:"Un pas aprés l'autre",
    giver:"Relais de Commandement",
    desc:"Détruis 3 Vorak rushers et 5 Orbes sentinelles dans Helion-01 ou Helion-02, puis rejoins les deux coordonnées indiquées.",
    objectives:[
      {id:"vorak", type:"kill", target:"raider_astral", label:"Vorak rusher", count:3, zones:["Helion-01","Helion-02"]},
      {id:"orbes", type:"kill", target:"drone_pirate", label:"Orbe sentinelle", count:5, zones:["Helion-01","Helion-02"]},
      {id:"coord_a", type:"visit_coordinates", label:"Coord X -430 Y 0", x:-430, y:0, scale:10, tolerance:6, zones:["Helion-01","Helion-02"], count:1},
      {id:"coord_b", type:"visit_coordinates", label:"Coord X 170 Y 120", x:170, y:120, scale:10, tolerance:6, zones:["Helion-01","Helion-02"], count:1}
    ],
    rewards:{credits:32000, premium:200, xp:5000, materials:{}}
  },
  {
    id:"quest_lv3_alert_vigilance",
    category:"normal",
    requiredLevel:3,
    title:"Alerte vigilence",
    rare:true,
    giver:"Relais de Commandement",
    desc:"Elimine les cibles demandees sans perdre plus de 3000 points de vie. Si la limite est depassee, la mission repart de zero.",
    unlock:{type:"complete_level_quests", level:3},
    objectives:[
      {id:"astra01_orbes", type:"kill", target:"drone_pirate", label:"Orbe sentinelle", count:5, zone:"Helion-01"},
      {id:"astra02_vorak", type:"kill", target:"raider_astral", label:"Vorak rusher", count:5, zone:"Helion-02"},
      {id:"astra02_parasites", type:"kill", target:"chasseur_spectral", label:"Parasite vert", count:2, zone:"Helion-02"}
    ],
    failConditions:{hpLossLimit:3000},
    rewards:{credits:250000, premium:800, xp:15000, materials:{}, ammo:{ammo_x2:3000}}
  },
  {
    id:"quest_lv4_establish_recon",
    category:"normal",
    requiredLevel:4,
    title:"Établir reconaissance",
    giver:"Relais de Commandement",
    desc:"Va dans Helion-02 et élimine 5 Parasites astraux et 5 Vorak rushers en moins de 5 minutes.",
    objectives:[
      {id:"astra02", type:"visit_map", map:"Helion-02", label:"Atteindre Helion-02", count:1},
      {id:"parasites", type:"kill", target:"chasseur_spectral", label:"Parasite vert", count:5, zone:"Helion-02"},
      {id:"vorak", type:"kill", target:"raider_astral", label:"Vorak rusher", count:5, zone:"Helion-02"}
    ],
    failConditions:{timeLimit:300},
    rewards:{credits:75000, premium:250, xp:6500, materials:{}}
  },
  {
    id:"quest_lv4_contaminated_samples",
    category:"normal",
    requiredLevel:4,
    title:"Echantillions contaminé",
    rare:true,
    giver:"Relais de Commandement",
    desc:"Détruis des Parasites astraux jusqu'à récupérer un échantillon contaminé. Si tu meurs avant de le rapporter au relais, l'échantillon est perdu.",
    unlock:{type:"complete_level_quests", level:4},
    objective:{type:"quest_item_drop", target:"chasseur_spectral", label:"Échantillon contaminé", itemId:"contaminated_sample", itemName:"Échantillon contaminé", itemImg:"assets/quest_items/contaminated_sample.png", dropChance:.20, count:1, zone:"Helion-02"},
    failConditions:{deathResets:true},
    rewards:{credits:350000, premium:1000, xp:20000, materials:{}, ammo:{rocket_r2:100}}
  },
  {
    id:"quest_lv5_call_for_help",
    category:"normal",
    requiredLevel:5,
    title:"Un apelle a l'aide",
    red:true,
    giver:"Relais de Commandement",
    desc:"Rejoins le portail ferme d'Helion-02, aide Ricky a repousser l'attaque, puis rapporte-lui le fluide de teleportation demande.",
    objectives:[
      {id:"portal_coord", type:"visit_coordinates", label:"Coord X 430 Y -330", x:430, y:-330, scale:10, tolerance:10, zone:"Helion-02", count:1},
      {id:"talk_start", type:"talk_npc", npcId:"astra02_portal_mechanic", label:"Parler a Ricky", zone:"Helion-02", count:1, requiresObjective:"portal_coord"},
      {id:"traqueurs", type:"kill", target:"cuirasse_nebulaire", label:"Traqueur abyssal", count:2, zone:"Helion-03", requiresObjective:"talk_start"},
      {id:"parasites", type:"kill", target:"chasseur_spectral", label:"Parasite vert", count:6, zones:["Helion-02","Helion-03"], requiresObjective:"talk_start"},
      {id:"vorak", type:"kill", target:"raider_astral", label:"Vorak rusher", count:8, zones:["Helion-01","Helion-02"], requiresObjective:"talk_start"},
      {id:"orbes", type:"kill", target:"drone_pirate", label:"Orbe sentinelle", count:15, zones:["Helion-01","Helion-02"], requiresObjective:"talk_start"},
      {id:"talk_return", type:"talk_npc", npcId:"astra02_portal_mechanic", label:"Retourner voir Ricky", zone:"Helion-02", count:1, requiresObjectives:["traqueurs","parasites","vorak","orbes"]},
      {id:"fluides", type:"deliver_item", npcId:"astra02_portal_mechanic", itemId:"teleportation_fluid", itemName:"Fluide de Teleportation", itemImg:"assets/quest_items/teleportation_fluid.png", label:"Ramener 10 fluides de teleportation", zone:"Helion-02", count:10, consumeItems:true, requiresObjective:"talk_return"}
    ],
    rewards:{credits:2000000, premium:10000, xp:300000, materials:{}, itemCounts:{teleportation_fluid:10}, items:["laser_mk3"], ammo:{ammo_x3:5000}}
  },
  {
    id:"quest_lv8_la_roue_tourne",
    category:"normal",
    requiredLevel:8,
    title:"La roue tourne",
    giver:"Relais de Commandement",
    desc:"Va dans les portails et lance le Space Caster x100 une fois.",
    objective:{type:"space_caster_use", label:"Space Caster", count:100, zone:"Portails"},
    rewards:{credits:150000, premium:300, xp:30000, materials:{}}
  },
  {
    id:"quest_lv8_un_deja_vu",
    category:"normal",
    requiredLevel:8,
    title:"Un Déjà vu",
    giver:"Relais de Commandement",
    desc:"Détruis 4 Boss Vorak rushers et 4 Boss Orbes sentinelles sans perdre plus de 2 000 points de vie. Si la limite est dépassée, la quête est annulée et doit être reprise.",
    objectives:[
      {id:"boss_vorak", type:"kill", target:"boss_raider_astral", label:"Boss Vorak rusher", count:4},
      {id:"boss_orbes", type:"kill", target:"boss_drone_pirate", label:"Boss Orbe sentinelle", count:4}
    ],
    failConditions:{hpLossLimit:2000},
    rewards:{credits:150000, premium:300, xp:30000, materials:{}}
  },
  {
    id:"quest_lv8_pendant_effort_pas_reconfort",
    category:"normal",
    requiredLevel:8,
    title:"Pendant l'effort, pas de réconfort",
    giver:"Relais de Commandement",
    desc:"Détruis 8 Parasites astraux et 6 Traqueurs abyssaux.",
    objectives:[
      {id:"parasites", type:"kill", target:"chasseur_spectral", label:"Parasite astral", count:8},
      {id:"traqueurs", type:"kill", target:"cuirasse_nebulaire", label:"Traqueur abyssal", count:6}
    ],
    rewards:{credits:150000, premium:300, xp:30000, materials:{}}
  },
  {
    id:"quest_lv8_je_l_avais_predit",
    category:"normal",
    requiredLevel:8,
    title:"Je l'avais prédit !",
    rare:true,
    giver:"Relais de Commandement",
    desc:"Détruis 4 Eclanites, 5 Parasites astraux et 5 Traqueurs abyssaux en moins de 10 minutes. Si le temps est dépassé, la quête est annulée et doit être reprise.",
    unlock:{type:"complete_level_quests", level:8},
    objectives:[
      {id:"cristaux", type:"kill", target:"eclanite", label:"Eclanite", count:4},
      {id:"parasites", type:"kill", target:"chasseur_spectral", label:"Parasite astral", count:5},
      {id:"traqueurs", type:"kill", target:"cuirasse_nebulaire", label:"Traqueur abyssal", count:5}
    ],
    failConditions:{timeLimit:600},
    rewards:{credits:1000000, premium:1200, xp:100000, materials:{}, ammo:{ammo_x3:3000}}
  },
  {
    id:"quest_lv9_ca_sent_le_poisson_pouris",
    category:"normal",
    requiredLevel:9,
    title:"Ça sent le poisson pouris",
    giver:"Relais de Commandement",
    desc:"Équipe au moins 8 lasers sur ton vaisseau actif. Tout vaisseau équipé de 8 lasers ou plus valide la quête.",
    objective:{type:"equipped_ship_lasers", label:"Lasers équipés sur le vaisseau", count:8, zone:"Hangar"},
    rewards:{credits:250000, premium:350, xp:45000, materials:{}}
  },
  {
    id:"quest_lv9_moucheron",
    category:"normal",
    requiredLevel:9,
    title:"Moucheron",
    giver:"Relais de Commandement",
    desc:"Détruis 40 Orbes sentinelles.",
    objective:{type:"kill", target:"drone_pirate", label:"Orbe sentinelle", count:40},
    rewards:{credits:250000, premium:350, xp:45000, materials:{}}
  },
  {
    id:"quest_lv9_ruee_vorak",
    category:"normal",
    requiredLevel:9,
    title:"Ruée de Vorak",
    giver:"Relais de Commandement",
    desc:"Détruis 30 Vorak rushers.",
    objective:{type:"kill", target:"raider_astral", label:"Vorak rusher", count:30},
    rewards:{credits:250000, premium:350, xp:45000, materials:{}}
  },
  {
    id:"quest_lv9_chasse_abyssale",
    category:"normal",
    requiredLevel:9,
    title:"Chasse abyssale",
    giver:"Relais de Commandement",
    desc:"Détruis 20 Traqueurs abyssaux.",
    objective:{type:"kill", target:"cuirasse_nebulaire", label:"Traqueur abyssal", count:20},
    rewards:{credits:250000, premium:350, xp:45000, materials:{}}
  },
  {
    id:"quest_lv9_reflets_du_neant",
    category:"normal",
    requiredLevel:9,
    title:"Reflets du néant",
    rare:true,
    giver:"Relais de Commandement",
    desc:"Détruis 10 Eclanites sans mourir. Si tu meurs, la quête est annulée et doit être reprise.",
    unlock:{type:"complete_level_quests", level:9},
    objective:{type:"kill", target:"eclanite", label:"Eclanite", count:10},
    failConditions:{deathResets:true},
    rewards:{credits:1200000, premium:1400, xp:125000, materials:{}, ammo:{rocket_r2:150}}
  },
  {
    id:"quest_lv10_maintenance_impossible",
    category:"normal",
    requiredLevel:10,
    title:"Maintenance impossible",
    giver:"Relais de Commandement",
    desc:"Retourne voir Ricky pres du portail ferme. Il lui faut 5 pieces de stabilisation recuperees en zone 4 de ta firme pour reparer l'armature du portail.",
    objectives:[
      {id:"talk_start", type:"talk_npc", npcId:"astra02_portal_mechanic", label:"Retourner voir Ricky", zone:"Helion-02", count:1},
      {id:"stabilisateurs", type:"quest_item_drop", itemId:"stabilisateur_dimensionnel", itemName:"Piece de stabilisation", itemImg:"assets/quest_items/stabilizer_part.png", label:"Pieces de stabilisation", dropChance:.15, count:5, zone:"Helion-04", requiresObjective:"talk_start"},
      {id:"talk_return", type:"talk_npc", npcId:"astra02_portal_mechanic", label:"Rapporter les pieces a Ricky", zone:"Helion-02", count:1, requiresObjective:"stabilisateurs"},
      {id:"mission_control", type:"mission_control", stationId:"quests", label:"Retourner au controleur de mission", zone:"Helion-01", count:1, requiresObjective:"talk_return"}
    ],
    rewards:{credits:500000, premium:400, xp:75000, materials:{}, itemCounts:{portal_anchor_key:1}}
  },
  {
    id:"quest_lv10_sauvons_deadly",
    category:"normal",
    requiredLevel:10,
    title:"Sauvons Deadly",
    red:true,
    giver:"Relais de Commandement",
    desc:"Entre dans le portail de Ricky, sauve Deadly puis retourne voir Ricky.",
    unlock:{type:"complete_quest", questId:"quest_lv10_maintenance_impossible"},
    objectives:[
      {id:"portal", type:"portal_complete", portalId:"ricky", label:"Terminer le portail de Ricky", count:1},
      {id:"talk_return", type:"talk_npc", npcId:"astra02_portal_mechanic", label:"Retourner voir Ricky", zone:"Helion-02", count:1, requiresObjective:"portal"}
    ],
    rewards:{credits:5000000, premium:15000, xp:3000000, materials:{}, items:["laser_mk3", "pistou_portgun"]}
  },
  {
    id:"quest_weekly_assault",
    category:"weekly",
    requiredLevel:10,
    title:"Contrat hebdomadaire",
    giver:"Relais de Commandement",
    desc:"Neutralise une force spectrale dans Helion-02. Contrat lourd reserve aux pilotes prepares.",
    objective:{type:"kill", target:"chasseur_spectral", count:15, zone:"Helion-02"},
    rewards:{credits:85000, xp:4200, materials:{silice_conductrice:18, catalyseur_quantique:2}}
  },
  ...generatedCombatQuests
];

export const questCatalog = buildFirmQuestCatalog(baseQuestCatalog);

export const pageText = {
  hangar:{title:"HANGAR", subtitle:"Configure ton vaisseau, tes drones et tes extras."},
  shop:{title:"MAGASIN", subtitle:"Progression par niveau : vaisseaux, lasers, roquettes, générateurs et drones."},
  store:{title:"BOUTIQUE", subtitle:"Packs premium, Nova, credits et starters."},
  firm:{title:"FIRME", subtitle:"Saison, contribution, quetes collectives, boutique et recompenses de firme."},
  portals:{title:"PORTAILS DIMENSIONNELS", subtitle:"Rassemble les fragments requis, puis affronte l’épreuve propre à chaque portail."},
  refinery:{title:"RAFFINERIE", subtitle:"Transforme tes matériaux bruts en ressources avancées pour améliorer ton équipement."},
  settings:{title:"PARAMÈTRES", subtitle:"Personnalise tes touches de slots."},
  leaderboard:{title:"CLASSEMENT", subtitle:"Classement local préparé pour le futur MMO : grades, points et règles de progression."}
};


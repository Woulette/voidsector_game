import { markProfileSaveAcknowledged } from "./profileSync.js?v=20260726-kharon1";
import { countCombatProfiler } from "../game/systems/combatFrameProfiler.js?v=20260726-kharon1";

function pushEvent(target, event, limit){
  target.push({...event, receivedAt:performance.now()});
  if(target.length > limit) target.splice(0, target.length - limit);
}

function isPreTransferCorrection(session, lastMapChange){
  if(session?.source !== "state-correction" || !lastMapChange) return false;
  if(session.isDead || Number(session.hp) <= 0) return false;
  const sourceSeq = Number(session.sourceSeq);
  return Number.isSafeInteger(sourceSeq) && sourceSeq > 0
    && sourceSeq < lastMapChange.sourceSeq
    && String(session.mapId ?? "") === lastMapChange.fromMapId;
}

export function installPlayerSocketListeners({
  socket,
  multiplayer,
  requestSocialSync,
  backgroundSync,
  upsertRemotePlayer,
  addRemoteEffect,
  emitChange,
  toast
}){
  socket.on("auth:required", payload=>{
    multiplayer.auth.profileReady = false;
    toast(payload?.message || "Compte MMO requis pour jouer.");
    emitChange("auth:required", payload);
  });
  socket.on("profile:sync", profile=>{
    multiplayer.auth.profileReady = true;
    if(profile && Object.hasOwn(profile, "preparedPortal")){
      multiplayer.preparedPortal = profile.preparedPortal
        ? {...profile.preparedPortal, receivedAt:performance.now()}
        : null;
    }
    requestSocialSync?.();
    window.dispatchEvent(new CustomEvent("voidsector:profile-sync", {detail:{profile}}));
    emitChange("profile:sync", profile);
  });
  socket.on("profile:setup-complete", event=>{
    toast(event?.firmLabel ? `Profil pilote pret : ${event.firmLabel}.` : "Profil pilote pret.");
    emitChange("profile:setup-complete", event);
  });
  socket.on("profile:setup-error", payload=>{
    toast(payload?.message || "Configuration du profil impossible.");
    emitChange("profile:setup-error", payload);
  });
  socket.on("profile:saved", event=>{
    markProfileSaveAcknowledged(event);
    emitChange("profile:saved", event);
  });
  socket.on("tutorial:updated", event=>{
    if(event?.rewardItemId) toast("Cadeau ouvert : Laser MK-III recu.");
    emitChange("tutorial:updated", event);
  });
  socket.on("tutorial:error", payload=>{
    toast(payload?.message || "Mise a jour du tutoriel impossible.");
    emitChange("tutorial:error", payload);
  });
  socket.on("profile:debug-firm-reset", event=>{
    toast("Choix de firme reinitialise pour les tests locaux.");
    emitChange("profile:debug-firm-reset", event);
  });
  socket.on("player:resume", session=>{
    pushEvent(multiplayer.resumeEvents, session, 10);
    window.dispatchEvent(new CustomEvent("voidsector:player-resume", {detail:{session}}));
    emitChange("player:resume", session);
  });
  socket.on("player:state-correction", session=>{
    countCombatProfiler("socket.playerStateCorrection", 1);
    // Only discard corrections produced before the map request; its rejection stays authoritative.
    if(multiplayer.lastPlayerMapChange?.socketId === socket.id
      && isPreTransferCorrection(session, multiplayer.lastPlayerMapChange)) return;
    window.dispatchEvent(new CustomEvent("voidsector:player-resume", {detail:{session}}));
    emitChange("player:state-correction", session);
  });
  socket.on("players:list", players=>{
    multiplayer.players = Array.isArray(players) ? players : [];
    const visibleIds = new Set(multiplayer.players
      .filter(player=>Boolean(player?.state))
      .map(player=>player?.id)
      .filter(Boolean));
    for(const id of multiplayer.remotePlayers.keys()){
      if(!visibleIds.has(id)) multiplayer.remotePlayers.delete(id);
    }
    for(const player of multiplayer.players){
      if(player?.id && player.id !== multiplayer.playerId && player.state){
        upsertRemotePlayer(player);
      }else if(player?.id && player.id !== multiplayer.playerId){
        multiplayer.remotePlayers.delete(player.id);
      }
    }
    emitChange();
  });
  socket.on("leaderboard:ranking", payload=>{
    backgroundSync?.markReceived("leaderboard:sync");
    multiplayer.leaderboardRanking = payload || null;
    multiplayer.leaderboardSync = {
      ...(multiplayer.leaderboardSync || {}),
      lastReceivedAt:Date.now()
    };
    emitChange("leaderboard:ranking", payload);
  });
  socket.on("player:state", upsertRemotePlayer);
  socket.on("player:laser", addRemoteEffect);
  socket.on("enemy:attack", effect=>{
    countCombatProfiler("socket.enemyAttack", 1);
    pushEvent(multiplayer.enemyAttackEvents, effect, 40);
  });
  socket.on("player:damage", event=>{
    countCombatProfiler("socket.playerDamage", 1);
    pushEvent(multiplayer.playerDamageEvents, event, 40);
  });
  socket.on("player:death", event=>pushEvent(multiplayer.playerDeathEvents, event, 10));
  socket.on("player:respawned", event=>pushEvent(multiplayer.playerRespawnEvents, event, 10));
  socket.on("portgun:started", event=>{
    pushEvent(multiplayer.portgunEvents, {type:"started", ...event}, 10);
    emitChange("portgun:started", event);
  });
  socket.on("portgun:cancelled", event=>{
    pushEvent(multiplayer.portgunEvents, {type:"cancelled", ...event}, 10);
    emitChange("portgun:cancelled", event);
  });
  socket.on("portgun:complete", event=>{
    pushEvent(multiplayer.portgunEvents, {type:"complete", ...event}, 10);
    emitChange("portgun:complete", event);
  });
  socket.on("portgun:error", payload=>{
    pushEvent(multiplayer.portgunEvents, {type:"error", ...payload}, 10);
    toast(payload?.message || "Teleportation Portgun impossible.");
    emitChange("portgun:error", payload);
  });
  socket.on("player:radiation", event=>pushEvent(multiplayer.playerRadiationEvents, event, 10));
  socket.on("player:respawn-error", payload=>{
    toast(payload?.message || "Respawn impossible.");
    emitChange("player:respawn-error", payload);
  });
  socket.on("player:status-effect", event=>pushEvent(multiplayer.playerStatusEffectEvents, event, 20));
  socket.on("player:reward", event=>pushEvent(multiplayer.playerRewardEvents, event, 40));
  socket.on("loot:drop", event=>pushEvent(multiplayer.lootDropEvents, event, 40));
  socket.on("loot:picked", event=>{
    pushEvent(multiplayer.lootPickupEvents, event, 40);
    emitChange("loot:picked", event);
  });
  socket.on("loot:error", payload=>{
    toast(payload?.message || "Ramassage impossible.");
    emitChange("loot:error", payload);
  });
}

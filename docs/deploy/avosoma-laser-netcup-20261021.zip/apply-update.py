"""Apply only the verified static-client audio update; never touches the MMO data."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("--root", required=True, help="Existing Avosoma web root")
parser.add_argument("--apply", action="store_true", help="Apply after checking every original file")
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
root = Path(args.root).resolve(strict=True)
manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

pending = []
for entry in manifest["files"]:
    path = (root / entry["path"]).resolve()
    source = (bundle / "files" / entry["path"]).resolve()
    if not path.is_relative_to(root) or not source.is_relative_to(bundle / "files"):
        raise SystemExit("Refused path outside the selected project")
    if digest(source) != entry["after_sha256"]:
        raise SystemExit("Invalid bundle: " + entry["path"])
    current = digest(path)
    if current == entry["after_sha256"]:
        continue
    if current != entry["before_sha256"]:
        raise SystemExit("STOP: server version differs: " + entry["path"] + ". No files changed.")
    pending.append((entry, path, source))

print(f"Preflight OK: {len(pending)} files to update; no server/database changes.")
if not args.apply or not pending:
    raise SystemExit(0)

stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-%f")
backup = root.parent / (root.name + "-audio-backup-" + stamp)
backup.mkdir()
for entry,path,_ in pending:
    if path.is_file():
        saved = backup / entry["path"]
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path,saved)
(backup / "manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")

def atomic_copy(source, target, mode):
    target.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent,prefix=".audio-update-",delete=False) as temporary:
        staged = Path(temporary.name)
        temporary.write(source.read_bytes())
        temporary.flush()
        os.fsync(temporary.fileno())
    os.chmod(staged,mode)
    os.replace(staged,target)

applied = []
try:
    for entry,path,source in pending:
        if digest(path) != entry["before_sha256"]:
            raise RuntimeError("File changed during deployment: " + entry["path"])
        mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
        atomic_copy(source,path,mode)
        applied.append((entry,path,mode))
    for entry,path,_ in applied:
        if digest(path) != entry["after_sha256"]:
            raise RuntimeError("Verification failed: " + entry["path"])
except Exception:
    # Restore only files written by this run and still matching this update.
    for entry,path,mode in reversed(applied):
        if digest(path) != entry["after_sha256"]:
            continue
        original = backup / entry["path"]
        if original.is_file():
            atomic_copy(original,path,mode)
        else:
            path.unlink()
    raise
print("Update applied and verified. Backup: " + str(backup))
print("No MMO service restart needed. Reload the game to load the new client modules.")

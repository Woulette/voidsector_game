import "./src/app.js?v=20261021-laser-double1";
